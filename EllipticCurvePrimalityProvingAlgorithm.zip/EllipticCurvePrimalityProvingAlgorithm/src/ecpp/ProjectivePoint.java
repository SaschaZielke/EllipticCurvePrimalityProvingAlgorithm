package ecpp;

import java.math.BigInteger;

/**
 * Diese Klasse repr�sentiert einen projektiven Punkt
 * @author Sascha Zielke
 *
 */
public class ProjectivePoint implements Comparable<ProjectivePoint> {
	
	//Koordinaten des Punktes
	private BigInteger x;
	private BigInteger y;
	private BigInteger z;
	
	/**
	 * Standardkonstruktor, erzeugt leeren Punkt
	 */
	public ProjectivePoint() {
		this.x = null;
		this.y = null;
		this.z = null;
	}
	
	/**
	 * Konstruktor, erzeugt Punkt mit den Koordinaten x, y und z.
	 * @param x
	 * @param y
	 * @param z
	 */
	public ProjectivePoint(BigInteger x, BigInteger y, BigInteger z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}
	
	/**
	 * Gibt den Wert von x zur�ck.
	 * @return
	 */
	public BigInteger getX() {
		return x;
	}
	
	/**
	 * Gibt den Wert von y zur�ck.
	 * @return
	 */
	public BigInteger getY() {
		return y;
	}
	
	/**
	 * Gibt den Wert von z zur�ck.
	 * @return
	 */
	public BigInteger getZ() {
		return z;
	}
	
	/**
	 * Setzt die x-Koordinate auf den �bergebenen Wert.
	 * @param x
	 */
	public void setX(BigInteger x) {
		this.x = x;
	}
	
	/**
	 * Setzt die y-Koordinate auf den �bergebenen Wert.
	 * @param x
	 */
	public void setY(BigInteger y) {
		this.y = y;
	}
	
	/**
	 * Setzt die z-Koordinate auf den �bergebenen Wert.
	 * @param x
	 */
	public void setZ(BigInteger z) {
		this.z = z;
	}
	
	/**
	 * Gibt die String-Repr�sentation des Punktes zur�ck
	 */
	public String toString() {
		return new String("("+x+" , "+y+" , "+z+")");
	}
	
	/**
	 * Sortiert die Punkte aufsteigend nach der Y-Koordinate, und falls diese gleich sind, danach absteigend f�r die X-Koordinate.
	 */
	@Override
	public int compareTo(ProjectivePoint p) {
		int compY = this.getY().compareTo(p.getY());
		if(compY == 0) {
			return p.getX().compareTo(this.getX());
		}
		return compY;
	}

	
}

package ecpp;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.SortedMap;

import ch.obermuhlner.math.big.BigComplex;
import ch.obermuhlner.math.big.BigComplexMath;
import ch.obermuhlner.math.big.BigDecimalMath;

import edu.jas.arith.ModInteger;
import edu.jas.arith.ModIntegerRing;
import edu.jas.poly.GenPolynomial;
import edu.jas.poly.GenPolynomialRing;
import edu.jas.poly.TermOrder;
import edu.jas.ufd.FactorFactory;
import edu.jas.ufd.Factorization;

/**
 * Dies ist die Hauptklasse des ECPP-Algorithmus. Hier werden alle Wesentlichen Berechnungen durchgef�hrt, die f�r die Berechnung des Primzahltests
 * ben�tigt werden. 
 * @author Sascha Zielke
 *
 */
public class EllipticCurvePrimalityProving {

	ArrayList<BigInteger> primeList;
	ArrayList<ProjectivePoint> discriminants;

	/**Eine Funktion die eine Liste aller Primzahlen bis 2^power berechnet. Sollte vor dem Ausf�hren aller anderen Methoden
	 * einmal mit power = 32 aufgerufen werden!
	 * 
	 * @param power Ein �bergebener int-Wert, der die Schranke angibt bis zu der alle Primzahlen berechnet werden sollen.
	 */
	public void getPrimeList(int power) {
		//Lege eine neue ArrayList an.
		ArrayList<BigInteger> list = new ArrayList<BigInteger>();
		//F�gt die Zahl 2 als Primzahl der Liste hinzu.
		list.add(BigInteger.valueOf(2));
		//Pr�ft f�r jede Zahl ab 3, ob sie eine Primzahl ist.
		for (long i = 3; i < Math.pow(2, power); i++) {
			//Dazu wird geschaut, ob die aktuelle Zahl durch einen der Primfaktoren in der bisherigen Liste geteilt werden kann.
			for (int j = 0; j < list.size(); j++) {
				BigInteger value = list.get(j);
				//Falls dies der Fall ist, ist die Zahl nicht prim.
				if (BigInteger.valueOf(i).mod(value).equals(BigInteger.ZERO)) {
					break;
				}
				//Falls der betrachtete Teil schon gr��er ist als die Wurzel der zu testenden Zahl ist die Zahl prim.
				if (value.compareTo(BigInteger.valueOf((long) Math.sqrt(i))) == 1) {
					list.add(BigInteger.valueOf(i));
					break;
				}
			}
		}
		//Gibt die Liste der Primzahlen zur�ck.
		primeList = list;
	}

	/**Eine Funktion die die Hilbertschen Klassenzahlen bis zu einer gegebenen Grenze der Diskriminanten bestimmt. Realisiert Algorithmus 7.5.8 aus PNC.
	 * Dieser Algorithmus sollte f�r eine ausreichend gro�e Zahl aufgerufen werden, bevor die Primzahltests gestartet werden.
	 * 
	 * @param number Eine �bergebene, beliebig gro�e Fundamentaldiskriminante
	 * @throws InterruptedException
	 * @return Gibt eine Liste der Hilbertschen Klassenzahl und der Summen der ersten Koeffizienten der bin�ren quadratischen Formen
	 *         zu den Diskriminanten aus.
	 */
	public void getClassNumbers(BigInteger number) throws InterruptedException {
		ArrayList<ProjectivePoint> list = new ArrayList<ProjectivePoint>();
		BigInteger D = BigInteger.ONE.negate();
		while (D.abs().compareTo(number) == -1) {
			// Pr�fe ob D eine Fundamentaldiskriminante ist:
			BigInteger toCheck = D.abs().mod(BigInteger.valueOf(16));
			if ((toCheck.equals(BigInteger.valueOf(3))) || (toCheck.equals(BigInteger.valueOf(4)))
					|| (toCheck.equals(BigInteger.valueOf(7))) || (toCheck.equals(BigInteger.valueOf(8)))
					|| (toCheck.equals(BigInteger.valueOf(11))) || (toCheck.equals(BigInteger.valueOf(15)))) {
				if (isSquareFree(getOddPart(D))) {
					//Falls ja starte die eigentliche Berechnung und speichere die Ergebnisse in einer Liste.
					ProjectivePoint toAdd = new ProjectivePoint(D, computeClassNumber(D).get(0), computeClassNumber(D).get(1));
					list.add(toAdd);
				}
			}
			D = D.subtract(BigInteger.ONE);
		}
		//Sortiert die Liste, damit sie nach zuerst nach Klassenzahl aufsteigen und dann nach Diskriminanten absteigend sortiert wird.
		Collections.sort(list);
		discriminants = list;
	}

	/**
	 * Gib den ungeraden Anteil einer ganzen Zahl zur�ck.
	 * @param a Die Zahl, deren ungerader Anteil bestimmt werden soll.
	 * @return Der ungerade Anteil der Zahl.
	 */
	private BigInteger getOddPart(BigInteger a) {
		//Teile solange durch 2, bis dies nicht mehr m�glich ist. Der Rest ist der ungerade Anteil.
		while (a.mod(BigInteger.valueOf(2)).equals(BigInteger.ZERO)) {
			a = a.divide(BigInteger.valueOf(2));
		}
		return a;
	}

	/**
	 * Pr�ft, ob eine gegebene Fundamentaldiskriminante quadratfrei ist. Also ob ihre Faktorisierung keinen doppelten Primfaktor enth�lt.
	 * @param a Die Zahl, die auf Quadratfreiheit �berpr�ft werden soll.
	 * @return Ein boolean-Wert, der angibt, ob die Zahl quadratfrei ist oder nicht.
	 * @throws InterruptedException
	 */
	private boolean isSquareFree(BigInteger a) throws InterruptedException {
		//Negiert die Zahl, da diese Funktion eigentlich nur f�r negative Fundamentaldiskriminanten aufgerufen wird.
		a = a.negate();
		//Falls die Zahl dann prim oder gleich 1 ist, ist sie offenbar quadratfrei.
		if ((primeList.contains(a)) || (a.equals(BigInteger.ONE))) {
			return true;
		}
		//Ansonsten wird die Zahl faktorisiert (das macht keine Probleme, da die Diskriminanten in der Regel sehr klein sind)
		ArrayList<BigInteger> factors = this.getFactorizationTrivial(a);
		//Anschlie�end schaut man, ob jeder Faktor nur einmal vorkommt. Dazu speichert man die Faktoren in ein Hashset, in dem jeder Wert nur einmal
		//vorkommt. Ist dies Set genauso gro� wie die Liste der Faktoren, kommt kein Faktor doppelt vor.
		Set<BigInteger> factorset = new HashSet<BigInteger>(factors);
		if (factorset.size() < factors.size()) {
			return false;
		}
		return true;
	}

	/**
	 * Eine naive Methode die Faktorisierung einer Zahl zu erhalten.
	 * @param n Die Zahl, deren Faktorisierung ermittelt werden soll.
	 * @return Eine ArrayList mit den Primfaktoren der Zahl.
	 */
	private ArrayList<BigInteger> getFactorizationTrivial(BigInteger n) {

		ArrayList<BigInteger> factors = new ArrayList<BigInteger>();
		ArrayList<BigInteger> tempfactors = new ArrayList<BigInteger>();
		//Schaut, ob die Zahl bereits prim ist, falls ja wird die Zahl selbst zur�ck gegeben.
		if (primeList.contains(n)) {
			factors.add(n);
			return factors;
		}
		//Ansonsten muss die Zahl faktorisiert werden.
		tempfactors.add(n);

		//Solange es noch Teilfaktoren gibt, die weiter faktorisiert werden m�ssen, versuche diese zu faktorisieren:
		while (!tempfactors.isEmpty()) {
			int actualFactors = tempfactors.size();
			for (int i = 0; i < actualFactors; i++) {
				BigInteger actualValue = tempfactors.get(i);
				//Versuche einen Faktor der zu faktorisierenden Zahl zu finden.
				BigInteger tempvalue = factorize(actualValue);
				//Falls der Faktor prim ist, f�ge ihn der Primfaktorenliste hinzu.
				if (primeList.contains(tempvalue)) {
					factors.add(tempvalue);
				//Ansonsten zu der Liste der Teilfaktoren, die noch faktorisiert werden m�ssen.
				} else {
					tempfactors.add(tempvalue);
				}
				//Teilt man die urspr�nglich zu pr�fende Zahl durch den gefundenen Teilfaktor, so erh�lt man einen weiteren Teilfaktor.
				BigInteger tempvalue2 = actualValue.divide(tempvalue);
				//Ist dieser prim, f�ge ihn der Liste der Primfaktoren hinzu.
				if (primeList.contains(tempvalue2)) {
					factors.add(tempvalue2);
				//Ansonsten der Liste der noch zu faktorisierenden Zahlen.
				} else {
					tempfactors.add(tempvalue2);
				}
			}
			//L�sche die Zahlen, die weiter faktorisiert wurden, aus der Liste der noch zu faktorisierenden Zahlen.
			for (int i = 0; i < actualFactors; i++) {
				tempfactors.remove(0);
			}
		}
		//Gib die Liste der Faktoren zur�ck.
		return factors;
	}
	
	/**
	 * Finde durch Probedivisionen einen Faktor der Zahl.
	 * @param n Zahl, zu der ein Faktor gefunden werden soll.
	 * @return Ein Faktor der Zahl n.
	 */
	public BigInteger factorize(BigInteger n) {
		BigInteger i = BigInteger.valueOf(2);
		while (i.compareTo(n) == -1) {
			if ((n.mod(i)).equals(BigInteger.ZERO)) {
				return i;
			}
			i = i.add(BigInteger.ONE);
		}
		return BigInteger.ZERO;
	}
	
	/**
	 * Methode, die die eigentliche Berechnung der Klassenzahl nach Algorithmus 7.5.8. aus PNC bewerkstelligt.
	 * @param D Diskriminante D, zu der die Klassenzahl berechnet werden soll.
	 * @return Gibt die Hilbertsche Klassenzahl und die Summe der ersten Koeffizienten der bin�ren quadratischen Formen
	 *         zur Diskriminante D aus.
	 */
	private ArrayList<BigInteger> computeClassNumber(BigInteger D) {
		//Initialisierungsschritt:
		ArrayList<BigInteger> returnValues = new ArrayList<BigInteger>();
		//Initialisiert die Variable f�r die Summe der Koeffizienten a aus den bin�ren quadratischen Formen
		BigInteger aSum = BigInteger.ZERO;
		BigInteger b = D.mod(BigInteger.valueOf(2));
		BigInteger r = this.bigDecimalSqrt((D.abs()).divide(BigInteger.valueOf(3)));
		BigInteger h = BigInteger.ZERO;
		BigInteger m;
		//�u�ere Schleife f�r b:
		while (b.compareTo(r) <= 0) {
			BigInteger[] test = (b.pow(2).subtract(D)).divideAndRemainder(BigInteger.valueOf(4));
			if (!test[1].equals(BigInteger.ZERO)) {
				b = b.add(BigInteger.ONE);
				continue;
			}
			m = test[0];
			BigInteger a = BigInteger.ONE;
			while (a.pow(2).compareTo(m) <= 0) {
				if (!(m.mod(a).equals(BigInteger.ZERO))) {
					a = a.add(BigInteger.ONE);
					continue;
				}
				BigInteger c = m.divide(a);
				if (b.compareTo(a) == 1) {
					a = a.add(BigInteger.ONE);
					continue;
				}
				//Starte Test auf Divisoren:
				if ((b.equals(a)) || (c.equals(a)) || (b.equals(BigInteger.ZERO))) {
					h = h.add(BigInteger.ONE);
				} else {
					h = h.add(BigInteger.valueOf(2));
				}
				aSum = aSum.add(a);
				a = a.add(BigInteger.ONE);
			}
			b = b.add(BigInteger.ONE);
		}
		returnValues.add(h);
		returnValues.add(aSum);
		return returnValues;
	}
	
	/**
	 * Berechnet das Hilbertsche Klassenpolynom zur Diskriminante D nach Algorithmus 7.5.8 aus PNC.
	 * @param D Die gegebene Diskriminante
	 * @param aSum Die gegebene Summe der Koeffizienten a aus den bin�ren quadratischen Formen.
	 * @return Das Hilbertsche Klassenpolynom zur Diskriminante D
	 */
	private Polynom getClassPolynomialBigDecimal(BigInteger D, BigInteger aSum) {
		//Bestimme Genauigkeit analog zur Bemerkung nach Algorithmus 7.5.8 (hier etwas genauer am Ende)
		MathContext mc = new MathContext(100, RoundingMode.HALF_UP);
		BigDecimal delta = BigDecimal.valueOf(Math.PI).multiply(BigDecimalMath.sqrt(new BigDecimal(D).abs(), mc));
		delta = delta.divide(BigDecimalMath.log(BigDecimal.valueOf(10), mc), mc);
		delta = delta.divide(new BigDecimal(aSum), mc);
		int precision = delta.intValue()+1;
		mc = new MathContext(precision*10, RoundingMode.HALF_UP);
		
		//Initialisierungsschritt:
		ComplexPolynom T = new ComplexPolynom(0);
		
		T.setCoefficient(0, BigComplex.ONE);
		BigInteger b = D.mod(BigInteger.valueOf(2));
		if(b.compareTo(BigInteger.ZERO) < 0) {
			b = b.add(BigInteger.valueOf(2));
		}
		BigInteger r = BigDecimalMath.sqrt((new BigDecimal(D.abs())).divide(BigDecimal.valueOf(3), mc), mc).toBigInteger();
		BigInteger m;
		//�u�ere Schleife f�r b:
		while(b.compareTo(r) <= 0) {
			BigInteger[] test = (b.pow(2).subtract(D)).divideAndRemainder(BigInteger.valueOf(4));
			if (!test[1].equals(BigInteger.ZERO)) {
				b = b.add(BigInteger.ONE);
				continue;
			}
			m = test[0];
			BigInteger a = BigInteger.ONE;
			while((a.pow(2)).compareTo(m) <= 0) {
				if(!((m.mod(a)).equals(BigInteger.ZERO))) {
					a = a.add(BigInteger.ONE);
					continue;
				}
				BigInteger c = m.divide(a);
				if(b.compareTo(a) > 0) {
					a = a.add(BigInteger.ONE);
					continue;
				}
			
				//Optionales Polynom-Setup:
				BigDecimal tauReal = (new BigDecimal(b, mc).negate()).divide(BigDecimal.valueOf(2).multiply(new BigDecimal(a)), mc);
				BigDecimal tauImag = (BigDecimalMath.sqrt(new BigDecimal(D.abs()), mc)).divide(BigDecimal.valueOf(2).multiply(new BigDecimal(a)), mc);
				BigComplex tau = BigComplex.valueOf(tauReal, tauImag);
				BigComplex j1 = BigComplex.valueOf((BigDecimal.valueOf(-4)).multiply(BigDecimalMath.pi(mc)).multiply(tau.im), BigDecimal.valueOf(4).multiply(BigDecimalMath.pi(mc)).multiply(tau.re));
				j1 = BigComplexMath.exp(j1, mc);
				BigComplex j2 = BigComplex.valueOf((BigDecimal.valueOf(-2)).multiply(BigDecimalMath.pi(mc)).multiply(tau.im), BigDecimal.valueOf(2).multiply(BigDecimalMath.pi(mc)).multiply(tau.re));
				j2 = BigComplexMath.exp(j2, mc);
				BigComplex f = this.jFunctionBigDecimal(j1, mc).divide(this.jFunctionBigDecimal(j2, mc), mc).round(mc);
				BigComplex j = BigComplexMath.pow(BigComplex.valueOf(BigDecimal.valueOf(256), BigDecimal.ZERO).multiply(f, mc).add(BigComplex.valueOf(BigDecimal.ONE, BigDecimal.ZERO)), 3, mc).divide(f, mc);
				
				//Beginne den Divisor-Test.
				ArrayList<BigComplex> coefficients = new ArrayList<BigComplex>();
				if((b.compareTo(a) == 0) || (c.compareTo(a) == 0) || (b.compareTo(BigInteger.ZERO) == 0)) {
					coefficients.add(j.negate());
					coefficients.add(BigComplex.ONE);
					
					T = T.multiply(new ComplexPolynom(coefficients));
				}
				else {
					coefficients.add(BigComplex.valueOf((j.abs(mc)).pow(2, mc), BigDecimal.ZERO));
					coefficients.add(BigComplex.valueOf((j.re.negate()).multiply(BigDecimal.valueOf(2)), BigDecimal.ZERO));
					coefficients.add(BigComplex.ONE);
					T = T.multiply(new ComplexPolynom(coefficients));
				}
				a = a.add(BigInteger.ONE);
			}
			b = b.add(BigInteger.ONE);
		}
		//Runde das Polynom:
		Polynom poly = new Polynom(BigInteger.valueOf(T.getOrder()));
		BigInteger i = BigInteger.ZERO;
		for(BigComplex coefficient : T.coefficients) {
			BigDecimal real = coefficient.re.setScale(precision, RoundingMode.HALF_UP);
			poly.setCoefficient(i, real.toBigInteger());
			i = i.add(BigInteger.ONE);
		}
		return poly;
	}
	
	/**
	 * Berechnet die Delta-Funktion einer bin�ren quadratischen Form aus Algorithmus 7.5.8 nach PNC, Seite 359f.
	 * @param q Der Wert q, dessen Delta-Funktion berechnet werden soll.
	 * @param mc Eine MathContext-Instanz, die die Rundungsgenauigkeit angibt.
	 * @return Den Wert der Delta-Funktion.
	 */
	private BigComplex jFunctionBigDecimal(BigComplex q, MathContext mc) {
		BigComplex sum = BigComplex.ZERO;
		//Approximiere zun�chst den Wert der unendlichen Reihe
		for(int n = 1; n <= 50; n++) {
			int yValue = n*(3*n-1)/2;
			BigComplex partialSum = BigComplexMath.pow(q, BigComplex.valueOf(new BigDecimal(yValue), BigDecimal.ZERO), mc);
			yValue = n*(3*n+1)/2;
			partialSum = partialSum.add(BigComplexMath.pow(q, BigComplex.valueOf(new BigDecimal(yValue), BigDecimal.ZERO), mc), mc);
			if((n % 2) == 0) {
				sum = sum.add(partialSum, mc);
			}
			else {
				partialSum = partialSum.negate();
				sum = sum.add(partialSum, mc);
			}
		}
		//Addiere danach die 1
		BigComplex one = BigComplex.ONE;
		BigComplex result = one.add(sum, mc);
		//Nehme das Ergebnis hoch 24
		result = BigComplexMath.pow(result, 24, mc);
		//Multipliziere es mit q und gebe es zur�ck.
		return q.multiply(result, mc);
	}
	
	/**
	 * Berechnet das Jacobi-Symbol einer Zahl a zum Modulus n nach PNC, Algorithmus 2.3.5
	 * @param a Zahl deren Jacobi-Symbol berechnet werden soll
	 * @param n Modulus, zu dem das Jacobi-Symbol berechnet werden soll
	 * @return Das Jacobi-Symbol von a und n
	 */
	public BigInteger jacobiSymbol(BigInteger a, BigInteger n) {
		a = a.mod(n);
		BigInteger t = BigInteger.ONE;
		while (!a.equals(BigInteger.ZERO)) {
			while (a.mod(BigInteger.valueOf(2)).equals(BigInteger.ZERO)) {
				a = a.divide(BigInteger.valueOf(2));
				if (n.mod(BigInteger.valueOf(8)).equals(BigInteger.valueOf(3))
						|| n.mod(BigInteger.valueOf(8)).equals(BigInteger.valueOf(5))) {
					t = t.negate();
				}
			}
			BigInteger help = a;
			a = n;
			n = help;
			if (a.mod(BigInteger.valueOf(4)).equals(n.mod(BigInteger.valueOf(4)))) {
				if (a.mod(BigInteger.valueOf(4)).equals(BigInteger.valueOf(3))) {
					t = t.negate();
				}
			}
			a = a.mod(n);
		}
		if (n.equals(BigInteger.ONE)) {
			return t;
		}
		return BigInteger.ZERO;
	}


	/**
	 * Berechnet die Quadratwurzel einer Zahl a modulo n mit dem Shank-Tonelli-Algorithmus (Algorithmus 2.3.8 in PNC).
	 * @param a Zahl deren Quadratwurzel bestimmt werden soll
	 * @param n Modulus zu dem die Quadratwurzel bestimmt werden soll
	 * @return Quadratwurzel von a modulo n
	 */
	public BigInteger squareRootModuloN(BigInteger a, BigInteger n) {
		BigInteger x = BigInteger.ZERO;
		a = a.mod(n);
		//Einfache F�lle: n = 3, 7 mod 8
		BigInteger nMod8 = n.mod(BigInteger.valueOf(8));
		if (nMod8.equals(BigInteger.valueOf(3)) || nMod8.equals(BigInteger.valueOf(7))) {
			x = a.modPow((n.add(BigInteger.ONE)).divide(BigInteger.valueOf(4)), n).mod(n);
			return x;
		}
		//n = 5 mod 8
		if (nMod8.equals(BigInteger.valueOf(5))) {
			x = a.modPow(n.add(BigInteger.valueOf(3)).divide(BigInteger.valueOf(8)), n).mod(n);
			BigInteger c = x.pow(2).mod(n);
			if (!c.equals(a.mod(n))) {
				x = x.multiply(
						BigInteger.valueOf(2).modPow(n.subtract(BigInteger.ONE).divide(BigInteger.valueOf(4)), n))
						.mod(n);
			}
			return x;
		}
		//n = 1 mod 8
		Random rnd = new Random();
		BigInteger d;
		do {
			d = new BigInteger(n.bitLength(), rnd);
		} while (d.compareTo(n) >= 0 || (d.compareTo(BigInteger.valueOf(2)) == -1) || !(jacobiSymbol(d, n).equals(BigInteger.valueOf(-1))));
		BigInteger t = n.subtract(BigInteger.ONE);
		BigInteger s = BigInteger.ZERO;
		while (t.mod(BigInteger.valueOf(2)).equals(BigInteger.ZERO)) {
			s = s.add(BigInteger.ONE);
			t = t.divide(BigInteger.valueOf(2));
		}
		BigInteger A = a.modPow(t, n).mod(n);
		BigInteger D = d.modPow(t, n).mod(n);
		BigInteger m = BigInteger.ZERO;
		BigInteger i = BigInteger.ONE;
		while (i.compareTo(s) == -1) {		
			if ((((A.multiply(D.modPow(m, n))).modPow(BigInteger.valueOf(2).modPow(s.subtract(BigInteger.ONE).subtract(i), n), n)))
					.equals(n.subtract(BigInteger.ONE))) {
				m = m.add(BigInteger.valueOf(2).modPow(i, n));
			}
			i = i.add(BigInteger.ONE);
		}
		x = a.modPow((t.add(BigInteger.ONE)).divide(BigInteger.valueOf(2)), n)
				.multiply(D.modPow(m.divide(BigInteger.valueOf(2)), n)).mod(n);
		return x;
	}
	

	/**
	 * Bestimmt eine L�sung der diophantischen Gleichung 4n = u^2+|D|v^2 mit dem Algorithmus von Cornacchia-Smith (Algorithmus 2.3.13 in PNC)
	 * @param n s. oben
	 * @param discriminant s. oben
	 * @return L�sung der obigen Gleichung
	 * @throws InterruptedException
	 */
	public Point cornacchiaSmith(BigInteger n, BigInteger discriminant) throws InterruptedException {
		// Pr�fe Eingaben:
		if (!(discriminant.compareTo(BigInteger.valueOf(4).negate().multiply(n)) == 1)) {
			return null;
		}
		if (!(discriminant.compareTo(BigInteger.ZERO) == -1)) {
			return null;
		}
		if (!((discriminant.mod(BigInteger.valueOf(4)).equals(BigInteger.ZERO))
				|| (discriminant.mod(BigInteger.valueOf(4)).equals(BigInteger.ONE)))) {
			return null;
		}
		// 1. Fall: n = 2;
		if (n.equals(BigInteger.valueOf(2))) {
			BigInteger toCheck = discriminant.add(BigInteger.valueOf(8));
			if (isSquare(toCheck)) {
				toCheck = bigDecimalSqrt(toCheck);
				Point solution = new Point(toCheck, BigInteger.ONE);
				return solution;
			} else
				return null;
		}
		// Teste L�sbarkeit:
		if (!jacobiSymbol(discriminant, n).equals(BigInteger.ONE)) {
			return null;
		}
		// Initialisiere Quadratwurzel modulo p:
		BigInteger x = squareRootModuloN(discriminant, n);
		if (!(x.mod(BigInteger.valueOf(2)).equals(discriminant.mod(BigInteger.valueOf(2))))) {
			x = n.subtract(x);
		}
		// Initialisiere die Euklidkette:
		BigInteger a = BigInteger.valueOf(2).multiply(n);
		BigInteger b = x;
		BigInteger c = bigDecimalSqrt(BigInteger.valueOf(4).multiply(n));
		// Euklidkette:
		while (b.compareTo(c) > 0) {
			BigInteger help = a;
			a = b;
			b = help.mod(b);
		}
		// Berechnung und Ausgabe:
		BigInteger t = (BigInteger.valueOf(4).multiply(n)).subtract(b.pow(2));
		if (!t.mod(discriminant.abs()).equals(BigInteger.ZERO)) {
			return null;
		}
		BigInteger toCheck = t.divide(discriminant.abs());
		
		if(!isSquare(toCheck)) {
			return null;
		}
		BigInteger y = bigDecimalSqrt(toCheck);
		Point solution = new Point(b, y);
		return solution;
	}

	/**
	 * Berechnet die Abrundung von Quadratwurzeln von BigInteger-Werten: Algorithmus
	 * 9.2.11 in Prime Numbers, A Computational Perspective.
	 */

	public BigInteger bigDecimalSqrt(BigInteger n) {
		int B = n.bitLength();
		BigDecimal potency = BigDecimal.valueOf(B);
		potency = potency.divide(BigDecimal.valueOf(2), 0, BigDecimal.ROUND_CEILING);
		potency = potency.round(new MathContext(0, RoundingMode.CEILING)); 
		BigInteger x = this.pow(BigInteger.valueOf(2), potency.toBigIntegerExact());
		BigInteger y;
		boolean foundRoot = false;
		while (!foundRoot) {
			BigInteger z = n.divide(x);
			y = (x.add(z)).divide(BigInteger.valueOf(2));
			if (y.compareTo(x) >= 0) {
				foundRoot = true;
				return x;
			} else {
				x = y;
			}
		}
		return null;
	}

	/**
	 * Schnelles Potenzieren von BigInteger-Werten mittels bin�rem Gitter
	 * @param x Basis
	 * @param y Exponent
	 * @return x^y
	 */
	public BigInteger pow(BigInteger x, BigInteger y) {
		//Bestimme den Binary-String von y.
		String bits = y.toString(2);
		//Setze das Ergebnis auf x
		BigInteger z = x;
		BigInteger a = BigInteger.ONE;
		int j = 0;
		//Betrachte die Bitrepr�sentation von y von hinten nach vorne
		for (j = bits.length() - 1; j > 0; j--) {
			//F�r eine 1 multipliziere mit x und quadriere das Ergebnis
			if (bits.charAt(j) == '1') {
				a = a.multiply(z);
			}
			//Sonst quadriere nur das Ergebnis.
			z = z.pow(2);
		}
		
		return a.multiply(z);
	}

	/**
	 * Testet, ob eine gegebene Zahl ein Quadrat ist oder nicht
	 * @param a Die Zahl, die getestet werden soll.
	 * @return Ein boolean-Wert der angibt, ob die Zahl ein Quadrat ist oder nicht.
	 */
	private boolean isSquare(BigInteger a) {
		if (bigDecimalSqrt(a).pow(2).equals(a)) {
			return true;
		}
		return false;
	}
	
	
	/**
	 * Die Methode, die den ECPP Primzahltest realisiert
	 * @param n Die Zahl, von der gepr�ft werden soll, ob sie prim ist.
	 * @param cert Ein anfangs leeren Primalit�tszertikat
	 * @return Ein boolean-Wert, der angibt, ob die Zahl prim ist oder nicht.
	 * @throws InterruptedException
	 */
	public boolean ecppStep(BigInteger n, PrimalityCertificate cert) throws InterruptedException{
		//Die Schranke, ab wann der Algorithmus angewendet wird, steht hier bei 2^22.
		if(n.compareTo(BigInteger.valueOf(2).pow(22)) < 0) {
			//Falls n < 2^22, pr�fe ob n in einer Liste von Primzahlen kleiner 2^22 enthalten ist, falls ja ist n prim. (Ersetzt Probedivisionen)
			if(primeList.contains(n)) {
				return true;
			}
			//Ansonsten ist sie zusammengesetzt.
			else {
				System.out.println("Die Zahl "+n+" ist nach dem Probedivisionen-Test zusammengesetzt!");
				return false;
			}
		}
		//Falls n > 2^22 starte den eigentlichen Algorithmus und pr�fe ob die Zahl stark pseudoprim ist, falls nicht, ist sie nicht prim.
		if(!n.isProbablePrime(20)) {
			System.out.println("Die Zahl "+n+" ist nach dem Miller-Rabin-Test zusammengesetzt!");
			return false;
		}
		BigInteger q = BigInteger.ZERO;
		BigInteger m = BigInteger.ZERO;
		ArrayList<Point> curveParameters = new ArrayList<Point>();
		//Berechne Wert, den ein Teiler q der Ordnung �bersteigen muss, damit die Faktorisierung valide ist:
		BigInteger borderForQ = (this.bigDecimalSqrt(this.bigDecimalSqrt(n)).add(BigInteger.ONE)).pow(2);
		
		
		outer: for(ProjectivePoint p : this.discriminants) {
			//W�hle Diskriminanten dekrementierend, beginnend bei denen mit der niedrigsten Klassenzahl (wird realisiert durch Sortierung der Liste
			//discriminants).
			BigInteger D = p.getX();
			//Ist D kein quadratischer Rest modulo n, w�hle eine neue Diskriminante
			if(!this.jacobiSymbol(D, n).equals(BigInteger.ONE)) {
				continue;
			}
			
			//Ansonsten bestimme die L�sungen von 4n = u^2+|D|v^2 mit Cornacchia-Smith (funktioniert immer, falls n prim ist).
			Point solution = new Point();
			try {
				solution = this.cornacchiaSmith(n, D);
			} catch (InterruptedException e) {
				continue;
			}
			
			if(solution == null) {
				continue;
			}
			
			
			BigInteger u = solution.getX();
			BigInteger v = solution.getY();
			
			ArrayList<BigInteger> possibleOrders = new ArrayList<BigInteger>();
			
			//Berechne die m�glichen Ordnungen nach den Vorgaben aus Algorithmus 2.63.
			if (D.equals(BigInteger.valueOf(-3))) {
				possibleOrders.add(n.add(BigInteger.ONE).add((u.add(BigInteger.valueOf(3).multiply(v))).divide(BigInteger.valueOf(2))));
				possibleOrders.add(n.add(BigInteger.ONE).add((u.subtract(BigInteger.valueOf(3).multiply(v))).divide(BigInteger.valueOf(2))));
				possibleOrders.add(n.add(BigInteger.ONE).add(u));
				possibleOrders.add(n.add(BigInteger.ONE).subtract(u));
				possibleOrders.add(n.add(BigInteger.ONE).subtract((u.add(BigInteger.valueOf(3).multiply(v))).divide(BigInteger.valueOf(2))));
				possibleOrders.add(n.add(BigInteger.ONE).subtract((u.subtract(BigInteger.valueOf(3).multiply(v))).divide(BigInteger.valueOf(2))));
			}
			if (D.equals(BigInteger.valueOf(-4))) {
				possibleOrders.add(n.add(BigInteger.ONE).add(u));
				possibleOrders.add(n.add(BigInteger.ONE).subtract(u));
				possibleOrders.add(n.add(BigInteger.ONE).add(BigInteger.valueOf(2).multiply(v)));
				possibleOrders.add(n.add(BigInteger.ONE).subtract(BigInteger.valueOf(2).multiply(v)));
			}
			if (D.compareTo(BigInteger.valueOf(-4)) == -1) {
				possibleOrders.add(n.add(BigInteger.ONE).add(u));
				possibleOrders.add(n.add(BigInteger.ONE).subtract(u));
				
			}
			
			//Versuche die m�glichen Ordnungen zu faktorisieren
			for(BigInteger order : possibleOrders) {
				//Versuche einen m�glichst gro�en, pseudoprimen Faktor q zu finden
				q = searchForFactorQ(order);
				//Pr�fe, ob der gefundene Faktor gro� genug und pseudoprim ist:
				if((q.compareTo(borderForQ) == 1) && (q.compareTo(n) == -1) && (q.isProbablePrime(20))) {
					//Falls dies der Fall ist, haben wir eine Kurve mit der passenden Faktorisierung gefunden und suchen die entsprechenden m�glichen
					//Kurvenparameter zur Diskriminante D.
					curveParameters = this.generateParameters(n, D);
					//Findet der Algorithmus wieder erwarten keine Parameter, so versuche eine neue Diskriminante.
					if(curveParameters == null) {
						continue outer;
					}
					//Sonst hat man die Kurve zur �berpr�fung gefunden und merkt sich ihre Ordnung
					m = order;
					//Suche die richtige Kurve zur gew�hlten Ordnung
					for(Point point : curveParameters) {
						
						BigInteger a = point.getX();
						BigInteger b = point.getY();
						//Konstruiere die elliptische Kurve zu den Kurvenparametern in Z/nZ.
						EllipticCurveModuloN curve = new EllipticCurveModuloN(a, b, n);	
						ProjectivePoint U = new ProjectivePoint();
						ProjectivePoint P = new ProjectivePoint();
						
						//Berechne Punkte U, solange bis U nicht das neutrale Element ist
							do {
								//W�hle Punkt auf Kurve
								P = this.createRandomPoint(a, b, n);
								//Falls dies nicht m�glich ist, ist n nicht prim.
								if(P == null) {
									return false;
								}
								try {
									U = curve.multiply(m.divide(q), P);
								//Falls man Werte in Z/nZ findet, die nicht invertierbar sind, ist n nicht prim.
								} catch (InversionFailedException e) {
									return false;
								}	
							} while(U.getZ().equals(BigInteger.ZERO));
							
							ProjectivePoint V = new ProjectivePoint();
							try {
								V = curve.multiply(m, P);
								//Falls man Werte in Z/nZ findet, die nicht invertierbar sind, ist n nicht prim.
							} catch (InversionFailedException e) {
								return false;
							}
							//Falls V nicht das neutrale Element ist, wurde der Ordnung die falsche Kurve zugewiesen, versuche andere Kurvenparameter.
							if(!V.getZ().equals(BigInteger.ZERO)) {
								continue;
							}
							
							//Falls die Bedingungen an U und V erf�llt sind, ist n prim, falls auch q prim ist.
							if(ecppStep(q, cert)) {
								//Sollte sich herausstellen, dass die Rekursion beweist, dass n prim ist, speichere den jeweiligen Zertifikateintrag im 
								//Zertifikat
								CertificateEntry entry = new CertificateEntry(n, a, b, m, q, U);
								cert.certificate.addFirst(entry);
								//Gebe zur�ck, dass n prim ist.
								return true;
							}
							//Falls q dann nicht prim ist, ist n auch nicht prim.
							else {
								return false;
							}
							
					}
				}
			}
			//Falls keine der Kurvenparameter zur gew�hlten Ordnung zugewiesen werden konnten, oder kein passender Faktor q von einer der Ordnungen gefunden
			//wurde, w�hle eine neue Diskriminante.
		}
		//Das sollte hoffentlich nie vorkommen!
		System.out.println("Programm am Ende angekommen. Irgendwas l�uft falsch!");
		return false;
	}
	
	/**
	 * Eine naive Methode, um einen Faktor gr��er Wurzel n von n zu finden.
	 * @param m Zahl, f�r die ein solcher Faktor gefunden werden soll
	 * @return Ein solcher Faktor.
	 */
	private BigInteger searchForFactorQ(BigInteger m) {
		for(BigInteger p : primeList) {
			if(p.equals(m)) {
				break;
			}
			while(m.mod(p).equals(BigInteger.ZERO)) {
				m = m.divide(p);
			}
			if(p.pow(2).compareTo(m) > 1) {
				break;
			}
		}
		return m;
	}
	
	/**
	 * Erzeugt einen zuf�lligen Punkt auf der elliptischen Kurve E: y^2 = x^3+ax+b in Z/nZ.
	 * @param a s.oben
	 * @param b s.oben
	 * @param n s.oben
	 * @return Der zuf�llige Punkt auf E.
	 */
	private ProjectivePoint createRandomPoint(BigInteger a, BigInteger b, BigInteger n) {
		BigInteger x;
		BigInteger Q;
		Random rnd = new Random();
		do {
			//Berechne zuf�lliges x
			do {
				x = new BigInteger(n.bitLength(), rnd);
			} while (x.compareTo(n) >= 0);
			//Berechne rechte Seite der Weierstra�-Gleichung
			Q = (x.pow(3).add(a.multiply(x)).add(b)).mod(n);	
			//Pr�fe das rechte Seite ein quadratischer Rest modulo n ist. Ist dies nicht der Fall, w�hle ein neues x.
		} while(!this.jacobiSymbol(Q, n).equals(BigInteger.ONE));
		
		//Berechne y als Quadratwurzel der rechten Seite modulo n.
		BigInteger y = this.squareRootModuloN(Q, n);
		
		//Erf�llen x und y jetzt nicht die Weierstra�-Gleichung lief irgendwas komisch und E ist keine elliptische Kurve.
		if(!(y.modPow(BigInteger.valueOf(2), n)).equals(Q)) {
			return null;
		}
		//Ansonsten erzeuge den Punkt und gebe ihn zur�ck.
		ProjectivePoint P = new ProjectivePoint(x, y, BigInteger.ONE);
		return P;
	}
		
	/**
	 * Generiert die Kurvenparameter zu einer m�glichen Ordnung
	 * @param n Zahl, deren Primalit�t mit dem ECPP �berpr�ft werden soll.
	 * @param discriminant Diskriminante die gerade f�r die �berpr�fungen gew�hlt wurde.
	 * @return
	 */
	private ArrayList<Point> generateParameters(BigInteger n, BigInteger discriminant) {
		ArrayList<Point> possibleParameters = new ArrayList<Point>();
		BigInteger g = BigInteger.ZERO;
		Random rnd = new Random();
		int i = 0;
		//Bestimme ein g in Z/nZ so, dass es weder quadratischer Rest, noch kubischer Rest modulo n ist.
		while((g.equals(BigInteger.ZERO)) || (this.isSquare(g) == true) || (discriminant.equals(BigInteger.valueOf(-3)) && ((n.mod(BigInteger.valueOf(3))).equals(BigInteger.ONE)) && (g.modPow((n.subtract(BigInteger.ONE)).divide(BigInteger.valueOf(3)), n).equals(BigInteger.ONE)))) {
			if(i < primeList.size()) {
				g = primeList.get(i);
				i++;
			}
			else {
				do {
					g = new BigInteger(n.bitLength(), rnd);
				} while ((g.compareTo(n) >= 0) || (g.compareTo(BigInteger.valueOf(3)) < 1));
			}
		}
		//Fall: D = -4
		if(discriminant.equals(BigInteger.valueOf(-4))) {
			for(int k = 0; k < 3; k++) {
				possibleParameters.add(new Point((g.pow(k)).negate().mod(n), BigInteger.ZERO));
			}
		}
		//Fall: D = -3
		if(discriminant.equals(BigInteger.valueOf(-3))) {
			for(int k = 0; k < 5; k++) {
				possibleParameters.add(new Point(BigInteger.ZERO, (g.pow(k)).negate().mod(n)));
			}
		}
		//Fall D < -4
		else {
			//Berechne Summe der Koeffizienten a in den bin�ren quadratischen Formen.
			BigInteger aSum = BigInteger.ZERO;
			int j = 0;
			do {
				if(this.discriminants.get(j).getX().equals(discriminant)) {
					aSum = this.discriminants.get(j).getZ();
					break;
				}
				j++;
			} while(true);
			//Berechne Hilbert Klassenpolynom zur Diskriminante D
			Polynom hilbertPolynomial = this.getClassPolynomialBigDecimal(discriminant, aSum);
			//Reduziere das Polynom modulo n.
			PolynomModN polyModN = new PolynomModN(hilbertPolynomial, n);
			//Bestimme die Nullstellen des Hilbert Polynoms in Z/nZ.
			ArrayList<BigInteger> roots = getRoots(polyModN, n);
			if(roots == null) {
				return null;
			}
			//Wende Formel f�r Kurvenparameter an.
			for(int k = 0; k < roots.size(); k++) {
				BigInteger root = roots.get(k);
				if(root.equals(BigInteger.ZERO) || root.equals(BigInteger.valueOf(1728))) {
					continue;
				}
				BigInteger c = roots.get(0).multiply((roots.get(0).subtract(BigInteger.valueOf(1728))).modInverse(n));
				BigInteger r = BigInteger.valueOf(-3).multiply(c).mod(n);
				BigInteger s = BigInteger.valueOf(2).multiply(c).mod(n);
				possibleParameters.add(new Point(r, s));
				possibleParameters.add(new Point(r.multiply(g.pow(2)).mod(n), s.multiply(g.pow(3)).mod(n)));
				return possibleParameters;
			}
		}
		return null;
	}	
	
	/**
	 * Berechnet die Nullstellen eines Polynoms modulo n mit Hilfe des Java Algebra Systems, welches an der Uni Mannheim entwickelt wurde (s. README)
	 * @param g Das Polynom dessen Nullstellen bestimmt werden sollen.
	 * @param n Gibt den zugrundeliegenden Restklassenring an.
	 * @return Liste der Nullstellen.
	 */
	public ArrayList<BigInteger> getRoots(PolynomModN g, BigInteger n) {
		//Initilaisiere Liste f�r Nullstellen
		ArrayList<BigInteger> roots = new ArrayList<BigInteger>();
		//Initialisiere Ring Z/nZ in einer Variablen x mit Standard-Term-Ordnung
		ModIntegerRing modring = new ModIntegerRing(n);
		TermOrder order = new TermOrder();
		String[] vars = new String[] { "x" };
		GenPolynomialRing<ModInteger> ring = new GenPolynomialRing<ModInteger>(modring, 1, order, vars);
		
		//Parse Polynom aus eigener Klasse PolynomModN in vorgebene Klasse:
		ArrayList<Term> terms = g.getTerms();
		ArrayList<BigInteger> values = new ArrayList<BigInteger>();
		ArrayList<Long> exponents = new ArrayList<Long>();
		for(Term term : terms) {
			values.add(term.getValue());
			exponents.add(term.getExponent().longValue());
		}
		StringBuilder str = new StringBuilder();
		for(int i = 0; i < terms.size(); i++) {
			String sep = new String();
			if(i != 0) {
				if(values.get(i).compareTo(BigInteger.ZERO) < 0) {
					sep = "-";
				}
				else {
					sep = "+";
				}
				str.append(sep);
			}
			str.append(values.get(i));
			str.append(" x^");
			str.append(exponents.get(i));
		}
		String parseString = str.toString();
		//Erzeuge nun das Polynom �ber Z/nZ
		GenPolynomial<ModInteger> poly = ring.parse(parseString);
		
		//Faktorisiere das Polynom und speichere die Faktoren in der vorgegebenen Datenstruktur:
		Factorization<ModInteger> engine = FactorFactory.getImplementation(modring);
		SortedMap<GenPolynomial<ModInteger>,Long> factors = engine.factors(poly);
		
		//Lese die Faktoren der Ordnung 1 aus, denn diese bergen die potenziellen Nullstellen:
		for (Entry<GenPolynomial<ModInteger>, Long> entry : factors.entrySet()) {
			for(int i = 0; i < entry.getValue(); i++) {
				if(entry.getKey().degree() > 1) {
					continue;
				}
				//Falls ein solcher Faktor gefunden wurde, lese den konstanten Term aus und f�ge das Inverse von diesem
				//(also die Nullstelle) der Nullstellenliste hinzu.
				Iterator<ModInteger> it = entry.getKey().coefficientIterator();
				ModInteger value = new ModInteger(modring);
				while(it.hasNext()) {
					value = it.next();
				}
				value = value.negate();
				roots.add(value.getVal());
			}
		}
		return roots;
	}
	
	// Hauptmethode zum Starten des Primzahltests:
	public static void main(String... args) throws Exception {

		// Erzeuge Instanz von EllipticCurvePrimalityProving, um die Methoden zu Testen
		EllipticCurvePrimalityProving test = new EllipticCurvePrimalityProving();
		// Erzeugt eine Liste der Primzahlen in [0, 2^value] wobei value der �bergabewert der Methode ist
		test.getPrimeList(22);

		System.out.println("Liste der Primzahlen wurde generiert!");
		System.out.println("-----------------------------------------");
		
		
		System.out.println("Generiere Liste von Fundamentaldiskriminanten");
		
		// Generiere Liste von Diskriminanten und Klassenzahl bis zum gegebenen Maximalwert der Diskriminante (erh�hen falls n�tig):
		test.getClassNumbers(BigInteger.valueOf(1000));
		
		BigInteger n = new BigInteger("4294967549");
		PrimalityCertificate cert = new PrimalityCertificate();
		
		//Teste, ob n prim ist. 
		long time1 = System.currentTimeMillis();
		if(test.ecppStep(n, cert) == true) {
			//Falls ja, gib dies aus,
			System.out.println("Die Zahl "+n.toString()+" ist prim!");
			//und berechne die ben�tigte Zeit,
			long time2 = System.currentTimeMillis();
			System.out.println("Die Berechnung des ECPP-Algorithmus dauerte "+(time2-time1)+" ms.");
			long time3 = System.currentTimeMillis();
			//Gib das Zertifikat aus und �berpr�fe es:
			System.out.println("Das Primalit�tszertifikat ist gegeben durch:");
			System.out.println(cert.toString());
			System.out.println("Das Zertifikat wurde erfolgreich gepr�ft: "+cert.checkCertificate());
			long time4 = System.currentTimeMillis();
			//Berechne die ben�tigte Zeit zum Pr�fen des Zertifikates und gib diese aus.
			System.out.println("Das Pr�fen des Zertifikates dauerte "+(time4-time3)+" ms.");
		}
		
		
		System.out.println("---------------------------------------------------------------------------------------------");
		
		
		
		/*
		//Initialisiere Zeitmessung f�r ECPP:
		long time1, time2, time3, time4;
		long ecpptime;
		long numberOfPrimes = 0;
		long certtime;
		long ecppTimeSum = 0;
		long certTimeSum = 0;
		
		// Teste den ECPP:
		// W�hle Zahl, deren Primalit�t �berpr�ft werden soll:
		// Hier kann man untere Schranke des zu pr�fenden Bereichs angeben. 
		BigInteger toTest = new BigInteger("1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000");
		// Es wird f�r 5000 Zahlen gepr�ft, ob sie prim sind oder nicht.
		for(int i = 0; i < 5000; i++) {
			
			//Starte Zeitmessung f�r ECPP:
			
			PrimalityCertificate cert = new PrimalityCertificate();
			
			//Teste, ob n prim ist. 
			time1 = System.currentTimeMillis();
			if(test.ecppStep(toTest, cert) == true) {
				//Falls ja, gib dies aus,
				System.out.println("Die Zahl "+toTest.toString()+" ist prim!");
				//speichere die ben�tigte Zeit,
				time2 = System.currentTimeMillis();
				ecpptime = time2-time1;
				ecppTimeSum += ecpptime;
				//merke die Anzahl der Primzahlen im Intervall.
				numberOfPrimes++;
				time3 = System.currentTimeMillis();
				//Stoppe anschlie�end die Zeit, die ben�tigt wird um das Zertifikat zu verifizieren!
				System.out.println("Das Primalit�tszertifikat ist gegeben durch:");
				System.out.println(cert.toString());
				System.out.println(cert.checkCertificate());
				time4 = System.currentTimeMillis();
				certtime = time4-time3;
				certTimeSum += certtime;
				
			}
			
			System.out.println("---------------------------------------------------------------------------------------------");
			toTest = toTest.add(BigInteger.ONE);
		}
		//Errechne Mittelwerte der ben�tigten Zeit.
		System.out.println("Durchschnittliche Dauer ECPP: " +ecppTimeSum/numberOfPrimes+ " ms.");
		System.out.println("Durchschnittliche Dauer Zertifikat: " +certTimeSum/numberOfPrimes+ " ms.");
		System.out.println("Anzahl gefundene Primzahlen: " +numberOfPrimes);
		*/
	}
}

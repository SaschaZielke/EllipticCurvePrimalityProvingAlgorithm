package ecpp;

import java.math.BigInteger;

/**
 * Die Klasse repr�sentiert einen Knoten von MyLinkedList
 * @author Sascha Zielke
 *
 */
public class MyNode {
	
	//Wert des Knotens
	BigInteger value;
	//Verweis auf den n�chsten Knoten in der Liste
	MyNode next;
	
	/**
	 * Konstruktor, erzeugt einen Knoten mit dem vorgegebenen Wert
	 * @param value
	 */
	public MyNode(BigInteger value) {
		this.value = value;
		this.next = null;
	}
	
	/**
	 * Setzt den Nachfolge-Knoten in der MyLinkedList
	 * @param next Der zu setzende Nachfolger
	 */
	public void setNext(MyNode next) {
		this.next = next;
	}
	
	/**
	 * Liest den Wert des Knotens aus
	 * @return Wert des Knotens
	 */
	public BigInteger getValue() {
		return this.value;
	}
	
	/**
	 * Setzt den Wert des Knotens auf den �bergebenen Wert
	 * @param value Zu setzender Wert
	 */
	public void setValue(BigInteger value) {
		this.value = value;
	}
	
	/**
	 * Gibt eine String-Repr�sentation des Knotens zur�ck.
	 */
	public String toString() {
		return new String(value.toString());
	}

}

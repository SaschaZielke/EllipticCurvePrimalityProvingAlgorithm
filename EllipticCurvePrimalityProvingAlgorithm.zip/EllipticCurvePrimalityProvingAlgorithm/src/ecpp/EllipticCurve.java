package ecpp;

import java.math.BigInteger;
/**
 * Diese Klasse repr�sentiert eine elliptische Kurve, gegeben durch eine Weierstra�-Gleichung der Form y^2 = x^3+ax+b �ber einem K�rper der 
 * Charakteristik ungleich 2 oder 3.
 * @author Sascha Zielke
 */
public class EllipticCurve {
	//Variablen, die die Parameter der Kurve definieren
	protected BigInteger a;
	protected BigInteger b;
	
	//Variable, die einen Punkt auf der Kurve repr�sentiert, auf dem arithmetische Operationen ausgef�hrt werden k�nnen.
	protected ProjectivePoint p = null;
	
	//Einige Hilfsvariablen, die f�r das Programm ben�tigt werden:
	protected final BigInteger four = BigInteger.valueOf(4);
	protected final BigInteger sixteen = BigInteger.valueOf(16);
	protected final BigInteger twentyseven = BigInteger.valueOf(27);
	protected final BigInteger thousendsevenhundredtwentyeight = BigInteger.valueOf(1728);
	
	/**
	* Konstruktor: Konstruiert eine Instanz einer elliptischen Kurve mit den �bergebenen Parametern.
	* @param a Parameter a der definierenden Weierstra�-Gleichung der elliptischen Kurve
	* @param b Parameter b der definierenden Weierstra�-Gleichung der elliptischen Kurve
	*/
	public EllipticCurve(BigInteger a, BigInteger b) {
		this.a = a;
		this.b = b;
	}
	
	/**
	 * Gibt den Parameter a der definierenden Weierstra�-Gleichung zur�ck.
	 * @return Parameter a der definierenden Weierstra�-Gleichung.
	 */
	public BigInteger getA() {
		return this.a;
	}
	
	/**
	 * Gibt den Parameter b der definierenden Weierstra�-Gleichung zur�ck.
	 * @return Parameter b der definierenden Weierstra�-Gleichung.
	 */
	public BigInteger getB() {
		return this.b;
	}
	
	/**
	 * Gibt den aktuell gespeicherten projektiven Punkt der elliptischen Kurve zur�ck.
	 * @return
	 */
	public ProjectivePoint getPoint() {
		return this.p;
	}
	
	/**
	 * Pr�ft, ob ein �bergebener Punkt auf der aktuellen Instanz der elliptischen Kurve liegt. Falls ja wird er mit der Instanz verkn�pft, um arithmetische
	 * Operationen durchf�hren zu k�nnen.
	 * @param p Ein Projektiver Punkt, der auf die elliptische Kurve gesetzt werden soll.
	 * @return Ein boolean-Wert, der angibt, ob das Setzen erfolgreich war oder nicht.
	 */
	public boolean setPoint(ProjectivePoint p) {
		if(checkIfPointIsOnCurve(p)) {
			this.p = p;
			return true;
		}
		else {
			return false;
		}
	}
	
	/**
	 * Pr�ft, ob ein gegebener projektiver Punkt auf der aktuellen Instanz einer elliptischen Kurve liegt
	 * @param p Der Punkt, zu dem �berpr�ft werden soll, ob er auf der elliptischen Kurve liegt.
	 * @return Ein boolean-Wert, der angibt, ob der Punkt auf der Kurve liegt oder nicht.
	 */
	protected boolean checkIfPointIsOnCurve(ProjectivePoint p) {
		//Der Punkt im Unendlichen liegt immer auf der Kurve
		if(p.getZ().equals(BigInteger.ZERO)) {
			return true;
		}
		//Ansonsten check, ob die Koordinaten des Punktes die definierede Weierstra�-Gleichung erf�llen.
		if(p.getY().pow(2).equals(p.getX().pow(3).add(a.multiply(p.getX())).add(b))) {
			return true;
		}
		return false;
	}
	
	/**
	 * Berechnet die Diskriminante der elliptischen Kurve
	 * @return Diskriminante der elliptischen Kurve
	 */
	public BigInteger discriminant() {
		return (sixteen.negate()).multiply((four.multiply(a.pow(3))).add(twentyseven.multiply(b.pow(2))));
	}
	
	/**
	 * Berechnet die j-Invariante der elliptischen Kurve
	 * @return j-Invariante der elliptischen Kurve
	 */
	public BigInteger jInvariant() {
		return thousendsevenhundredtwentyeight.multiply(four.multiply(a.pow(3))).divide(four.multiply(a.pow(3)).add(twentyseven.multiply(b.pow(2))));
	}
	
	/**
	 * Negiert den aktuell gesetzten Punkt P. Berechnet also -P.
	 * @return Der negierte Punkt -P.
	 */
	public ProjectivePoint negate() {
		if(this.p == null) {
			System.out.println("Es wurde noch kein Punkt in der Kurve gesetzt");
			return null;
		}
		return new ProjectivePoint(this.p.getX(), this.p.getY().negate(), this.p.getZ());
	}
	
	/**
	 * Addierte Punkte auf der elliptischen Kurve und speichert das Ergebnis.
	 * @param other Punkt mit dem der Punkt auf der Kurve addiert werden soll.
	 * @return Ergebnis der Addition
	 * @throws InversionFailedException Wenn die abgeleitete Methode in EllipticCurveModuloN auf einem nicht-primen Restklassenring aufgerufen wird und bei der Berechnung der Summe ein Element betrachtet wird, das kein Inverses besitzt.
	 *         
	 */
	public ProjectivePoint add(ProjectivePoint other) throws InversionFailedException {
		//Pr�ft, ob ein Punkt auf der Kurve gesetzt wurde, denn sonst kann keine Addition durchgef�hrt werden.
		if(this.p == null) {
			System.out.println("Es wurde noch kein Punkt in der Kurve gesetzt");
			return null;
		}
		//Pr�ft, ob ein Punkt �bergeben wurde, denn sonst kann keine Addition durchgef�hrt werden.
		if(other == null) {
			System.out.println("Es wurde kein sinnvoller Punkt �bergeben");
			return null;
		}
		//Ist eines der beiden Element das neutrale Element, so wird der jeweils andere Punkt zur�ckgegeben.
		if(this.p.getZ().equals(BigInteger.ZERO)) {
			return other;
		}
		if(other.getZ().equals(BigInteger.ZERO)) {
			return this.p;
		}
		
		//Ansonsten wird die Formel aus Satz 2.25 durchgerechnet:
		BigInteger m;
		
		if(this.p.getX().equals(other.getX())) {
			if(this.p.getY().add(other.getY()).equals(BigInteger.ZERO)) {
				return new ProjectivePoint(BigInteger.ZERO, BigInteger.ONE, BigInteger.ZERO);	
			}
			m = (BigInteger.valueOf(3).multiply(this.p.getX().pow(2)).add(a)).divide(BigInteger.valueOf(2).multiply(this.p.getY()));
		}
		else {
			m = (other.getY().subtract(this.p.getY())).divide(other.getX().subtract(this.p.getX()));
		}
		BigInteger newX = m.pow(2).subtract(this.p.getX()).subtract(other.getX());
		return new ProjectivePoint(newX, m.multiply(this.p.getX().subtract(newX)).subtract(this.p.getY()), BigInteger.ONE);
	}
	
	/**
	 * Addiert den Punkt auf der elliptischen Kurve mit sich selbst und gibt das Ergebnis zur�ck.
	 * @return Das doppelte des Punktes
	 * @throws InversionFailedException
	 */
	public ProjectivePoint doublePoint() throws InversionFailedException {
		if (this.p == null) {
			System.out.println("Es wurde noch kein Punkt in der Kurve gesetzt");
			return null;
		}
		return add(this.p);
	}
	
	
	/**
	 * Subtrahiert einen �bergebenen Punkt von dem Punkt, der auf der Kurve gespeichert wurde und gibt das Ergebnis zur�ck.
	 * @param other Der �bergebene Punkt, der abgezogen werden soll.
	 * @return Die Differenz der beiden Punkte.
	 * @throws InversionFailedException
	 */
	public ProjectivePoint subtract(ProjectivePoint other) throws InversionFailedException {
		//Pr�ft, ob ein Punkt auf der Kurve gesetzt wurde, denn sonst kann keine Addition durchgef�hrt werden.
		if(this.p == null) {
			System.out.println("Es wurde noch kein Punkt in der Kurve gesetzt");
			return null;
		}
		//Pr�ft, ob ein Punkt �bergeben wurde, denn sonst kann keine Addition durchgef�hrt werden.
		if(other == null) {
			System.out.println("Es wurde kein sinnvoller Punkt �bergeben");
			return null;
		}
		//Addiert mit dem negierten des �bergebenen Punktes.
		return add(new ProjectivePoint(other.getX(), other.getY().negate(), other.getZ()));
	}
	
	/**
	 * Berechnet das n-fache eines �bergebenen Punktes und gibt diesen zur�ck.
	 * @param n Die Anzahl, wie oft der Punkt mit sich selbst addiert werden soll.
	 * @param point Der Punkt der mit sich selbst addiert werden soll.
	 * @return Das Ergebnis der n-fachen Addition
	 * @throws InversionFailedException
	 */
	public ProjectivePoint multiply(BigInteger n, ProjectivePoint point) throws InversionFailedException {
		if(n.equals(BigInteger.ZERO)) {
			return new ProjectivePoint(BigInteger.ZERO, BigInteger.ONE, BigInteger.ZERO);
		}
		BigInteger m = n.multiply(BigInteger.valueOf(3));
		String mString = m.toString(2);
		
		String nString = n.toString(2);
		
		while(mString.length() > nString.length()) {
			nString = "0"+nString;
		}
		int B = nString.length();
		ProjectivePoint Q = point;
		this.setPoint(Q);
		for(int j = 1; j < B-1; j++) {
			Q = doublePoint();
			this.setPoint(Q);
			if(mString.charAt(j) == '1' && nString.charAt(j) == '0') {
				Q = add(point);
				this.setPoint(Q);
			}
			if(mString.charAt(j) == '0' && nString.charAt(j) == '1') {
				Q = subtract(point);
				this.setPoint(Q);
			}
		}
		return Q;
		
		
	}
	
	/**
	 * Gibt die String-Repr�sentation der aktuellen Instanz einer elliptischen Kurve zur�ck.
	 */
	public String toString() {
		String s = new String("y^2 = x^3+"+a+"*x+"+b);
		return s;
	}
	
	

}

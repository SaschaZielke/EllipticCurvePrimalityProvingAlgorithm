package ecpp;

import java.math.BigInteger;

/**
 * Diese Klasse realisiert einen Punkt in der affinen Ebene.
 * @author Sascha Zielke
 *
 */

public class Point{
	
	//Koordinaten des Punktes
	BigInteger x;
	BigInteger y;
	
	/**
	 * Standardkonstruktor, erzeugt leeren Punkt
	 */
	public Point() {
		this.x = null;
		this.y = null;
	}
	
	/**
	 * Konstruktor, erzeugt Punkt mit den �bergebenen x- und y-Koordinaten.
	 * @param x s.oben
	 * @param y s.oben
	 */
	public Point(BigInteger x, BigInteger y) {
		this.x = x;
		this.y = y;
	}
	
	/**
	 * Setzt den x-Wert des Punktes
	 * @param x 
	 */
	public void setX(BigInteger x) {
		this.x = x;
	}
	
	/**
	 * Setzt den y-Wert des Punktes
	 * @param y
	 */
	public void setY(BigInteger y) {
		this.y = y;
	}
	
	/**
	 * Gibt den x-Wert des Punktes zur�ck
	 * @return
	 */
	public BigInteger getX() {
		return this.x;
	}
	
	/**
	 * Gibt den y-Wert des Punktes zur�ck
	 * @return
	 */
	public BigInteger getY() {
		return this.y;
	}
	
	/**
	 * Gibt eine String-Repr�sentation des Punktes zur�ck.
	 */
	public String toString() {
		return new String("("+x+" , "+y+")");
	}

}

package ecpp;

import java.math.BigInteger;

/**
 * Diese Klasse repr�sentiert einen Eintrag des Primalit�tszertifikates f�r den ECPP-Test, gem�� Abschnitt 2.2.3 der Arbeit.
 * @author Sascha Zielke
 *
 */

public class CertificateEntry {
	
	//Klassenvariablen, die die einzelnen Parameter eines Zertifikateintrags repr�sentieren
	BigInteger n;
	BigInteger a;
	BigInteger b;
	BigInteger m;
	BigInteger s;
	ProjectivePoint U;
	
	/**
	 * Konstruktor, der einen Zertifikateintrags mit den gegebenen Parameters erzeugt.
	 * @param n Die Zahl, deren Primalit�t getestet werden sollte.
	 * @param a Der Parameter a der elliptischen Kurve, auf der die Berechnungen durchgef�hrt wurden.
	 * @param b Der Parameter b der elliptischen Kurve, auf der die Berechnungen durchgef�hrt wurden.
	 * @param m Die Ordnung der elliptischen Kurve, auf der die Berechnungen durchgef�hrt wurden.
	 * @param s Der Teiler der Ordnung, so dass s > sqrt(n^{1/4} + 1)^2
	 * @param U Der Punkt auf der Kurve, der f�r Schritt 5 und 6 von Algorithmus 2.63 ben�tigt wird.
	 */
	public CertificateEntry(BigInteger n, BigInteger a, BigInteger b, BigInteger m, BigInteger s, ProjectivePoint U) {
		this.n = n;
		this.a = a;
		this.b = b;
		this.m = m;
		this.s = s;
		this.U = U;
	}
	
	/**
	 * Gibt die zu testende Zahl zur�ck.
	 * @return Die zu testende Zahl n.
	 */
	public BigInteger getN() {
		return this.n;
	}
	
	/**
	 * Gibt den Parameter a der elliptischen Kurve zur�ck, auf der die Berechnungen durchgef�hrt wurden.
	 * @return Parameter a der elliptischen Kurve.
	 */
	public BigInteger getA() {
		return this.a;
	}
	
	/**
	 * Gibt den Parameter b der elliptischen Kurve zur�ck, auf der die Berechnungen durchgef�hrt wurden.
	 * @return Parameter b der elliptischen Kurve.
	 */
	public BigInteger getB() {
		return this.b;
	}
	
	/**
	 * Gibt die Ordnung m der elliptischen Kurve zur�ck, auf der die Berechnungen durchgef�hrt wurden.
	 * @return Ordnung m der elliptischen Kurve.
	 */
	public BigInteger getM() {
		return this.m;
	}
	
	/**
	 * Gibt den Teiler s der Ordnung m der elliptischen Kurve zur�ck.
	 * @return Teiler s der Ordnung m der elliptischen Kurve.
	 */
	public BigInteger getS() {
		return this.s;
	}
	
	/**
	 * Gibt den Punkt zur�ck, auf dem die Berechnung f�r Schritt 5 und 6 durchgef�hrt wurden.
	 * @return Punkt, auf dem Berechnungen durchgef�hrt wurden.
	 */
	public ProjectivePoint getU() {
		return this.U;
	}
	
	/**
	 * Gibt die String-Repr�sentation des Zertifikateintrags zur�ck.
	 */
	public String toString() {
		return("(n = "+n.toString()+", a = "+a.toString()+", b = "+b.toString()+", m = "+m.toString()+", s = "+s.toString()+", U = "+U.toString()+")");
	}
	
	

}

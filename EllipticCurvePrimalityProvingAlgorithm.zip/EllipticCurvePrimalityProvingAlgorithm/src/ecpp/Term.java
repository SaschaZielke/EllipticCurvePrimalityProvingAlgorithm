package ecpp;

import java.math.BigInteger;

/**
 * Diese Klasse repr�sentiert ein Monom eines Polynom Modulo N
 * @author Sascha Zielke
 *
 */

public class Term implements Comparable<Term>{
	
	//Wert des Monoms
	BigInteger value;
	//Exponent des Monoms
	BigInteger exponent;
	
	/**
	 * Erzeugt ein Monom mit dem Wert value und dem Exponent exponent
	 * @param exponent
	 * @param value
	 */
	public Term(BigInteger exponent, BigInteger value) {
		this.exponent = exponent;
		this.value = value;
	}
	
	/**
	 * Setzt den Wert des Monoms auf value.
	 * @param value
	 */
	public void setValue(BigInteger value) {
		this.value = value;
	}
	
	/**
	 * Gibt den Exponent des Monoms zur�ck.
	 * @return
	 */
	public BigInteger getExponent() {
		return this.exponent;
	}
	
	/**
	 * Gibt den Wert des Monoms zur�ck.
	 * @return
	 */
	public BigInteger getValue() {
		return this.value;
	}

	/**
	 * Dient zum Sortieren der Monomliste in PolynomModN
	 */
	@Override
	public int compareTo(Term other) {
		return -this.exponent.compareTo(other.exponent);
	}
	
	/**
	 * Gibt eine String-Repr�sentation des Monoms zur�ck.
	 */
	public String toString() {
		String s = new String();
		if(value.compareTo(BigInteger.ZERO) >= 0) {
			s = s+"+";
		}
		else {
			s = s+"-";
		}
		if(exponent.equals(BigInteger.ZERO)) {
			s = s+value;
		}
		else {
			s = s+value+"*x^"+exponent;
		}
		return s;
	}

}

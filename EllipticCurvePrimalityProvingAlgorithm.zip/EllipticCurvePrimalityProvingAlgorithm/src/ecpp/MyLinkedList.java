package ecpp;

import java.math.BigInteger;

/**
 * Eine Klasse, die eine verkettete Liste von BigInteger-Werten realisiert:
 * @author Sascha Zielke
 *
 */
public class MyLinkedList {
	
	//Erster Eintrag der Liste
	MyNode head;
	//Letzter Eintrag der Liste
	MyNode last;
	//L�nge der Liste
	BigInteger size;
	
	/**
	 * Standardkonstruktor, erzeugt leere Liste
	 */
	public MyLinkedList() {
		head = null;
		size = BigInteger.ZERO;
	}
	
	/**
	 * Konstruktor, erzeugt Liste einer vorgegeben L�nge, initialisiert die Eintr�ge mit Nullen.
	 * @param size
	 */
	public MyLinkedList(BigInteger size) {
		head = null;
		this.size = BigInteger.ZERO;
		while(this.size.compareTo(size) < 0) {
			add(BigInteger.ZERO);
		}
	}
	
	/**
	 * Gibt die L�nge der Liste zur�ck
	 * @return L�nge der Liste
	 */
	public BigInteger size() {
		return this.size;
	}
	
	/**
	 * F�gt einen neuen Wert ans Ende der Liste an
	 * @param value Einzuf�gender Wert.
	 */
	public void add(BigInteger value) {
		MyNode newNode = new MyNode(value);
		//Falls die Liste leer ist, initialsiere sie mit dem neuen Knoten
		if(size.equals(BigInteger.ZERO)) {
			head = newNode;
			last = newNode;
			size = size.add(BigInteger.ONE);
			return;
			
		}
		//Ansonsten f�ge ihn hinten an
		last.setNext(newNode);
		last = last.next;
		size = size.add(BigInteger.ONE);
		return;
	}
	
	/**
	 * Lese den Wert an einer Stelle der Liste aus
	 * @param index Stelle, deren Wert ausgelesen werden soll
	 * @return Wert an der �bergebenen Stelle der Liste
	 */
	public BigInteger get(BigInteger index) {
		//Laufe vom ersten Knoten bis zum Knoten an der Stelle index.
		BigInteger actualIndex = BigInteger.ZERO;
		MyNode actual = head;
		while(actualIndex.compareTo(index) < 0) {
			actual = actual.next;
			actualIndex = actualIndex.add(BigInteger.ONE);
		}
		//Lese den Wert aus:
		return actual.getValue();
	}
	
	/**
	 * Ver�ndere den Wert an einer gegebenen Stelle
	 * @param index Stelle, an der der Wert ver�ndert werden soll
	 * @param value Wert der gesetzt werden soll
	 */
	public void set(BigInteger index, BigInteger value) {
		//Laufe bis zur gegebenen Stelle
		BigInteger actualIndex = BigInteger.ZERO;
		MyNode actual = head;
		while(actualIndex.compareTo(index) < 0) {
			actual = actual.next;
			actualIndex = actualIndex.add(BigInteger.ONE);
		}
		//Ver�ndere den Wert
		actual.setValue(value);
	}
	
	/**
	 * Entfernt das letzte Element der Liste
	 */
	public void removeLast() {
		//Laufe bis zum letzten Element
		MyNode actual = head;
		MyNode prev = null;
		while(actual.next != null) {
			prev = actual;
			actual = actual.next;
		}
		//L�sche das letzte Element
		if(prev != null) {
			prev.setNext(null);
			size = size.subtract(BigInteger.ONE);
		}
		
	}
	
	/**
	 * Erzeugt eine tiefe Kopie der Liste
	 * @return Tiefe Kopie der aktuellen Instanz
	 */
	public MyLinkedList deepCopy() {
		MyLinkedList newList = new MyLinkedList(this.size());
		BigInteger i = BigInteger.ZERO;
		while(i.compareTo(this.size()) < 0) {
			//Erzeugt automatisch neuen Knoten!
			newList.set(i, this.get(i));
			i = i.add(BigInteger.ONE);
		}
		return newList;
	}
	
}

package ecpp;

import java.math.BigInteger;


/**
 * Diese Klasse repr�sentiert ein Polynom mit ganzzahligen, beliebig gro�en Koeffizienten
 * @author Sascha Zielke
 *
 */

public class Polynom {
	//LinkedList zur Repr�sentation der Koeffizienten
	MyLinkedList coefficients;
	//Ordnung des Polynoms
	BigInteger order;

	/**
	 * Konstruktor des Polynoms, erzeugt Polynom mit vorgegebener Ordnung.
	 * @param order
	 */
	public Polynom(BigInteger order) {
		this.order = order;
		this.coefficients = new MyLinkedList(order.add(BigInteger.ONE));
	}
	
	/**
	 * Konstruktor des Polynoms, erzeugt Polynom aus Koeffizientenliste
	 * @param coefficients
	 */
	public Polynom(MyLinkedList coefficients) {
		this.order = coefficients.size().subtract(BigInteger.ONE);
		this.coefficients = coefficients;
	}
	
	/**
	 * Setzt den Koeffizient des Terms der vorgegebenen Ordnung auf den vorgegebenen Wert
	 * @param order Vorgegebene Ordnung
	 * @param value Vorgegebener Wert
	 */
	public void setCoefficient(BigInteger order, BigInteger value) {
		this.coefficients.set(order, value);
	}
	
	/**
	 * Gibt die Ordnung des Polynoms zur�ck
	 * @return
	 */
	public BigInteger getOrder() {
		return this.order;
	}
	
 
    
	//Ausgabe eines Polynoms
	public String toString() {
		BigInteger order = coefficients.size().subtract(BigInteger.ONE);
		StringBuilder s = new StringBuilder();
		while(order.compareTo(BigInteger.ZERO) > 0) {
			s.append(coefficients.get(order).toString());
			s.append("*x^");
			s.append(order).toString();
			s.append("+");
			order = order.subtract(BigInteger.ONE);
		}
		s.append(coefficients.get(BigInteger.ZERO));
		return s.toString();
	}
	


}

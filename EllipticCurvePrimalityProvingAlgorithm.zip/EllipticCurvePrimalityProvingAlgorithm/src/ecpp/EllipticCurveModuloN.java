package ecpp;

import java.math.BigInteger;

/**
 * Diese Klasse repr�sentiert eine elliptische Kurve, gegeben durch eine Weierstra�-Gleichung der Form y^2 = x^3+ax+b �ber Restklassenring der Charakteristik
 * ungleich 2 oder 3 (Man spricht von Charakteristik, da man annimmt, dass n prim ist und der Restklassenring daher ein K�rper ist).
 * @author sasch
 *
 */
public class EllipticCurveModuloN extends EllipticCurve {

	//Modulus zu dem reduziert wird
	BigInteger n;

	/**
	 * Konstruiert eine elliptische Kurve in Z/nZ
	 * @param a Parameter a der Weierstra�-Gleichung
	 * @param b Parameter b der Weierstra�-Gleichung
	 * @param n Modulus zu dem reduziert wird.
	 */
	public EllipticCurveModuloN(BigInteger a, BigInteger b, BigInteger n) {
		super(a, b);
		this.a = a.mod(n);
		this.b = b.mod(n);
		this.n = n;
	}

	/**
	 * Versucht einen Punkt auf der Kurve zu speichern.
	 * 
	 */
	public boolean setPoint(ProjectivePoint p) {
		//Pr�ft, ob der gegebene Punkt auf der Kurve liegt.
		if (checkIfPointIsOnCurve(p)) {
			p.setX(p.getX().mod(n));
			p.setY(p.getY().mod(n));
			p.setZ(p.getZ().mod(n));
			this.p = p;
			return true;
		//Falls nicht, kann er nicht gesetzt werden.
		} else {
			return false;
		}
	}

	/**
	 * Pr�ft, ob ein gegebener Punkt auf der Kurve liegt oder nicht.
	 * 
	 */
	protected boolean checkIfPointIsOnCurve(ProjectivePoint p) {
		//Der Punkt im Unendlichen liegt auf jeder Kurve
		if (p.getZ().equals(BigInteger.ZERO)) {
			return true;
		}
		//Ansonsten pr�fe, ob der Punkt die Weierstra�-Gleichung erf�llt.
		if ((p.getY().pow(2)).mod(n).equals(
				(p.getX().pow(3).add(a.multiply(p.getX())).add(b)).mod(n))) {
			return true;
		}
		return false;
	}

	/**
	 * Negiert den Wert eines Punktes P. Berechnet also -P.
	 * 
	 */
	public ProjectivePoint negate() {
		//Pr�ft ob ein Punkt gesetzt wurde, der negiert werden kann
		if (this.p == null) {
			System.out.println("Es wurde noch kein Punkt in der Kurve gesetzt");
			return null;
		}
		//Berechnet den negierten Punkt 
		return new ProjectivePoint(this.p.getX().mod(n), this.p.getY().negate().mod(n),
				this.p.getZ().mod(n));
	}

	/**
	 * Addiert zwei Punkte auf der Kurve
	 *
	 */
	public ProjectivePoint add(ProjectivePoint other) throws InversionFailedException {
		//Testet, ob ein Punkt gesetzt wurde. Sonst ist keine Addition m�glich.
		if(this.p == null) {
			System.out.println("Es wurde noch kein Punkt in der Kurve gesetzt");
			return null;
		}
		//Testet, ob ein Punkt �bergeben wurde. Sonst ist keine Addition m�glich.
		if(other == null) {
			System.out.println("Es wurde kein sinnvoller Punkt �bergeben");
			return null;
		}
		//Testet, ob einer der beiden Punkt das neutrale Element ist, dann ist das Ergebnis der Addition der andere Punkt.
		if(this.p.getZ().equals(BigInteger.ZERO)) {
			return other;
		}
		if(other.getZ().equals(BigInteger.ZERO)) {
			return this.p;
		}
		
		//Ansonsten wird die Formel aus Satz 2.25 durchgerechnet:
		BigInteger m;
		
		if(this.p.getX().equals(other.getX())) {
			if(this.p.getY().add(other.getY()).mod(n).equals(BigInteger.ZERO)) {
				return new ProjectivePoint(BigInteger.ZERO, BigInteger.ONE, BigInteger.ZERO);	
			}
			try {
				m = BigInteger.valueOf(3).multiply(this.p.getX().pow(2)).add(a).mod(n).multiply((BigInteger.valueOf(2).multiply(this.p.getY()).mod(n)).modInverse(n));
				BigInteger newX = m.pow(2).subtract(this.p.getX()).subtract(other.getX()).mod(n);
				return new ProjectivePoint(newX, m.multiply(this.p.getX().subtract(newX)).subtract(this.p.getY()).mod(n), BigInteger.ONE);
			}
			catch(ArithmeticException e) {
				//Inversion fehlgeschlagen:
				throw new InversionFailedException(BigInteger.valueOf(2).multiply(this.p.getY()).mod(n).toString());
			}
		}
		else {
			try {
				m = other.getY().subtract(this.p.getY()).mod(n).multiply(other.getX().subtract(this.p.getX()).modInverse(n));
				BigInteger newX = m.pow(2).subtract(this.p.getX()).subtract(other.getX()).mod(n);
				return new ProjectivePoint(newX, m.multiply(this.p.getX().subtract(newX)).subtract(this.p.getY()).mod(n), BigInteger.ONE);
			}
			catch(ArithmeticException e) {
				//Inversion fehlgeschlagen:
				throw new InversionFailedException(other.getX().subtract(this.p.getX()).toString());
			}
		}
	}

	/**
	 * Verdoppelt den Wert eines Punktes auf der Kurve
	 */
	public ProjectivePoint doublePoint() throws InversionFailedException {
		if (this.p == null) {
			System.out.println("Es wurde noch kein Punkt in der Kurve gesetzt");
			return null;
		}
		return add(this.p);
	}
	
	/**
	 * Subtrahiert einen �bergebenen Punkt von dem Punkt auf der Kurve. 
	 */
	public ProjectivePoint subtract(ProjectivePoint other) throws InversionFailedException {
		if(this.p == null) {
			System.out.println("Es wurde noch kein Punkt in der Kurve gesetzt");
			return null;
		}
		if(other == null) {
			System.out.println("Es wurde kein sinnvoller Punkt �bergeben");
			return null;
		}
		return add(new ProjectivePoint(other.getX().mod(n), other.getY().negate().mod(n), other.getZ().mod(n)));
	}
	
	/**
	 * Berechnet das n-fache des �bergebenen Punktes.
	 */
	public ProjectivePoint multiply(BigInteger n, ProjectivePoint point) throws InversionFailedException {
		if(n.equals(BigInteger.ZERO)) {
			return new ProjectivePoint(BigInteger.ZERO, BigInteger.ONE, BigInteger.ZERO);
		}
		BigInteger m = n.multiply(BigInteger.valueOf(3));
		String mString = m.toString(2);
		
		String nString = n.toString(2);
		
		while(mString.length() > nString.length()) {
			nString = "0"+nString;
		}
		int B = nString.length();
		ProjectivePoint Q = point;
		this.setPoint(Q);
		for(int j = 1; j < B-1; j++) {
			Q = doublePoint();
			this.setPoint(Q);
			if(mString.charAt(j) == '1' && nString.charAt(j) == '0') {
				Q = add(point);
				this.setPoint(Q);
			}
			if(mString.charAt(j) == '0' && nString.charAt(j) == '1') {
				Q = subtract(point);
				this.setPoint(Q);
			}
		}
		return Q;
	}

	/**
	 * Berechnet die Diskriminante der Kurve.
	 */
	public BigInteger discriminant() {
		return super.discriminant().remainder(n);
	}

	/**
	 * Berechnet die j-Invariante der Kurve.
	 */
	public BigInteger jInvariant() {
		return super.jInvariant().remainder(n);
	}

}

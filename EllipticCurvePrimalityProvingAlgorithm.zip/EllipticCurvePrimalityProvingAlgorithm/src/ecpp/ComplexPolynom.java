package ecpp;

import java.util.ArrayList;

import ch.obermuhlner.math.big.BigComplex;

/**
 * Diese Klasse repr�sentiert ein Polynom mit komplexen Koeffizienten. Die Real- und Imagin�rteile der Koeffizienten sind dabei ganzzahlig und beliebig gro�.
 * @author sasch
 *
 */
public class ComplexPolynom {
	
	//Eine ArrayList, die die Koeffizienten des Polynoms �ber den ganzen komplexen Zahlen speichert.
	ArrayList<BigComplex> coefficients;
	//Die Ordnung des Polynoms
	int order;

	/**
	 * Konstruktor, der ein komplexes Polynom einer vorgegebenen Ordnung erzeugt.
	 * @param order
	 */
	public ComplexPolynom(int order) {
		//Ordnung wird gesetzt.
		this.order = order;
		//Koeffizientenliste wird initialisiert
		this.coefficients = new ArrayList<BigComplex>(order+1);
		
		for(int i = 0; i <= order; i++) {
			this.coefficients.add(BigComplex.ZERO);
		}
		
	}
	
	/**
	 * Konstruktor der ein komplexes Polynom aus einer ArrayList von BigComplex Koeffizienten erzeugt.
	 * @param coefficients Die Koeffizientenliste f�r das Polynom.
	 */
	public ComplexPolynom(ArrayList<BigComplex> coefficients) {
		this.order = coefficients.size()-1;
		this.coefficients = coefficients;
		
	}
	
	/**
	 * Setzt den Koeffizient des Monoms der �bergebenen Ordnung order auf den �bergebenen Wert
	 * @param order �bergebene Ordnung
	 * @param value �bergebener Wert
	 */
	public void setCoefficient(int order, BigComplex value) {
		this.coefficients.set(order, value);
	}
	
	/**
	 * Gibt die Ordnung des komplexen Polynoms zur�ck
	 * @return Ordnung des komplexen Polynoms
	 */
	public int getOrder() {
		return this.order;
	}
	
	
	/**
	 * Addiert das aktuelle komplexe Polynom mit einem �bergebenen und gibt das Ergebnis zur�ck.
	 * @param other Polynom, das addiert werden soll.
	 * @return Ergebnis der Addition
	 */
	public ComplexPolynom add(ComplexPolynom other) {
		//Bestimme, welches Polynom die h�here Ordnung hat.
		int maxSize = Math.max(this.coefficients.size(), other.coefficients.size());
		//F�lle beide Koeffizientenlisten auf, sodass sie gleich lang sind
		ArrayList<BigComplex> newCoefficients = new ArrayList<BigComplex>();
		int thisSize = this.coefficients.size();
		while(thisSize < maxSize) {
			this.coefficients.add(BigComplex.ZERO);
			thisSize++;
		}

		int otherSize = other.coefficients.size();
		while(otherSize < maxSize) {
			other.coefficients.add(BigComplex.ZERO);
			otherSize++;
		}
		//Addiere die Koeffizienten in beiden Listen Schritt f�r Schritt.
		for(int i = 0; i < maxSize; i++) {
			newCoefficients.add(this.coefficients.get(i).add(other.coefficients.get(i)));
		}
		//Gib die Summe zur�ck.
		return new ComplexPolynom(newCoefficients);
	}
	
	/**
	 * Subtrahiert ein �bergebenes komplexes Polynom vom aktuellen komplexen Polynom und gibt das Ergebnis zur�ck.
	 * @param other Polynom das subtrahiert werden soll.
	 * @return Ergebnis der Subtraktion
	 */
	public ComplexPolynom subtract(ComplexPolynom other) {
		//Bestimmt, welches Polynom die h�here Ordnung hat.
		int maxSize = Math.max(this.coefficients.size(), other.coefficients.size());
		//F�lle beide Koeffizientenlisten auf, sodass sie gleich lang sind
		ArrayList<BigComplex> newCoefficients = new ArrayList<BigComplex>();
		int thisSize = this.coefficients.size();
		while(thisSize < maxSize) {
			this.coefficients.add(BigComplex.ZERO);
			thisSize++;
		}
	
		int otherSize = other.coefficients.size();
		while(otherSize < maxSize) {
			other.coefficients.add(BigComplex.ZERO);
			otherSize++;
		}
	
		//Subtrahiere die Koeffizienten in beiden Listen Schritt f�r Schritt.
		for(int i = 0; i < maxSize; i++) {
			newCoefficients.add(this.coefficients.get(i).subtract(other.coefficients.get(i)));
		}
		
		//Gib das neue Polynom zur�ck.
		return new ComplexPolynom(newCoefficients);
	}
	
	/**
	 * Multipliziert das �bergebene komplexe Polynom mit dem aktuellen.
	 * @param other Das zu multiplizierende Polynom
	 * @return Ergebnis der Multiplikation
	 */
	public ComplexPolynom multiply(ComplexPolynom other) {
		//Die Ordnung des neuen Polynoms ist die Summe der Ordnungen der urspr�nglichen Polynome.
		int newOrder = this.order+other.order;
		ArrayList<BigComplex> product = new ArrayList<BigComplex>(order+1);
		//F�lle beied Koeffizientenliste auf, sodass sie gleich lang sind.
		int thisOrder = this.order;
		for(int i = thisOrder+1; i < newOrder+1; i++) {
			this.coefficients.add(BigComplex.ZERO);
		}
		int otherOrder = other.order;
		for(int i = otherOrder+1; i < newOrder+1; i++) {
			other.coefficients.add(BigComplex.ZERO);
		}
		//Berechne das Ergebnis Monom f�r Monom
		for(int i = 0; i < newOrder+1; i++) {
			BigComplex newCoefficient = BigComplex.ZERO;
			//Addiere Koeffizienten zu den gleichen Monompotenzen, um das Monom zu bestimmen.
			for(int j = 0; j <= i; j++) {
				newCoefficient = newCoefficient.add(this.coefficients.get(i-j).multiply(other.coefficients.get(j)));
			}
			product.add(newCoefficient);
		}
		return new ComplexPolynom(product);
	}
	
	
	/**
	 * Gibt die String-Repr�sentation eines komplexen Polynoms zur�ck.
	 */
	public String toString() {
		int order = coefficients.size();
		StringBuilder s = new StringBuilder();
		while(order > 1) {
			s.append(coefficients.get(order-1));
			s.append("*x^");
			s.append(order-1);
			s.append("+");
			order--;
		}
		if(order == 1) {
			s.append(coefficients.get(0));
		}
		return s.toString();
	}

}

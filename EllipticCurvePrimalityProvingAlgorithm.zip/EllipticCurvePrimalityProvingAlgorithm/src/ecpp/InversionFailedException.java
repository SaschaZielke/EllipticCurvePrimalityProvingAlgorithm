package ecpp;

/**
 * Die Klasse realisiert eine Exception, die immer dann geworfen wird, wenn bei einer Berechnung zu einem Element in Z/nZ kein Inverses gefunden wird.
 * @author Sascha Zielke
 *
 */

public class InversionFailedException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	InversionFailedException() {
		
	}
	
	/**
	 * Konstruiert eine Exception mit der �bergebenen Fehlermeldung
	 * @param s Die �bergebene Fehlermeldung.
	 */
	InversionFailedException(String s) {
		super(s);
	}

}

package ecpp;


import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;

/**
 * Diese Klasse repr�sentiert ein Polynom in Z/nZ mit beliebig gro�en Koeffizienten
 * @author Sascha Zielke
 *
 */
public class PolynomModN {

	//Eine Liste von Monomen
	ArrayList<Term> terms;
	//Der Modulus zu dem reduziert wird:
	BigInteger n;
	
	/**
	 * Standardkonstruktor, erzeugt leeres Polynom Modulo n
	 * @param n
	 */
	public PolynomModN(BigInteger n) {
		this.n = n;
		this.terms = new ArrayList<Term>();
	}
	
	/**
	 * Konstruktor, erzeugt Polynom Modulo n aus einem normalen Polynom
	 * @param poly
	 * @param n
	 */
	public PolynomModN(Polynom poly, BigInteger n) {
		this.n = n;
		this.terms = new ArrayList<Term>();
		BigInteger i = BigInteger.ZERO;
		//Gehe �ber die Liste der Koeffizienten und reduziere sie modulo n.
		while(i.compareTo(poly.getOrder()) <= 0) {
			BigInteger value = poly.coefficients.get(i);
			if(value.equals(BigInteger.ZERO)) {
				i = i.add(BigInteger.ONE);
				continue;
			}
			this.setTerm(new Term(i, value));
			i = i.add(BigInteger.ONE);
		}
	}
	
	/**
	 * Ver�ndert ein Monom auf das �bergebene Monom
	 * @param term Das �bergebene Monom
	 */
	public void setTerm(Term term) {
		//Ermittele den Exponenten des zu setzenden Monoms
		BigInteger exponent = term.getExponent();
		if(exponent.compareTo(BigInteger.ZERO) < 0) {
			exponent = exponent.add(n);
		}
		//Suche das richtige Monom und setze den Wert
		for(Term actualTerm : terms) {
			if(actualTerm.getExponent().equals(exponent)) {
				actualTerm.setValue(term.getValue().mod(n));
				return;
			}
		}
		//Falls das passende Monom noch nicht in der Liste der Monome enthalten ist, f�ge ein neues Monom hinzu.
		term.setValue(term.getValue().mod(n));
		this.terms.add(term);
		Collections.sort(this.terms);
	}
	
	
	/**
	 * Gibt die Liste der Monome des Polynoms zur�ck
	 * @return
	 */
	public ArrayList<Term> getTerms() {
		return terms;
	}
	
	/**
	 * Gibt die Ordnung des Polynoms zur�ck
	 * @return
	 */
	public BigInteger getOrder() {
		if(terms.size() == 0) {
			return BigInteger.ZERO;
		}
		else return terms.get(0).getExponent();
	}
	
	/**
	 * Gibt eine String-Repr�sentation des Polynoms zur�ck.
	 */
	public String toString() {
		String s = new String();
		for(Term term : terms) {
			s = s+term.toString();
		}
		return s;
	}
	
	
	
	/* Methoden, die durch die Verwendung des Java Algebra System nicht l�nger ben�tigt werden: */
	
	/*
	public void setTermAdd(Term term) {
		if(term.getValue().equals(BigInteger.ZERO)) {
			return;
		}
		BigInteger exponent = term.getExponent();
		for(Term actualTerm : terms) {
			if(actualTerm.getExponent().equals(exponent)) {
				actualTerm.setValue(actualTerm.getValue().add(term.getValue()).mod(n));
				return;
			}
		}
		term.setValue(term.getValue().mod(n));
		this.terms.add(term);
		Collections.sort(this.terms);
	}
	
	public void setCoefficient(BigInteger exponent, BigInteger value) {
		if(value.equals(BigInteger.ZERO)) {
			return;
		}
		Term term = new Term(exponent, value);
		setTerm(term);
	}
	 
	public PolynomModN add(PolynomModN other) {
		PolynomModN sum = new PolynomModN(n);
		int i = 0;
		int j = 0;
		while((i < terms.size()) && (j < other.getTerms().size())) {
			BigInteger expI = terms.get(i).getExponent();
			BigInteger expJ = other.getTerms().get(j).getExponent();
			if(expI.compareTo(expJ) > 0) {
				sum.setTerm(terms.get(i));
				i++;
			}
			else if(expI.equals(expJ)) {
				BigInteger sumValue = terms.get(i).getValue().add(other.getTerms().get(j).getValue()).mod(n);
				if(!sumValue.equals(BigInteger.ZERO)) {
					sum.setTerm(new Term(expI, sumValue));
				}
				i++;
				j++;
			}
			else {
				sum.setTerm(other.getTerms().get(j));
				j++;
			}
		}
		while(i < terms.size()) {
			sum.setTerm(terms.get(i));
			i++;
		}
		while(j < other.getTerms().size()) {
			sum.setTerm(other.getTerms().get(j));
			j++;
		}
		return sum;
	}
	
	public PolynomModN subtract(PolynomModN other) {
		PolynomModN difference = new PolynomModN(n);
		int i = 0;
		int j = 0;
		while((i < terms.size()) && (j < other.getTerms().size())) {
			BigInteger expI = terms.get(i).getExponent();
			BigInteger expJ = other.getTerms().get(j).getExponent();
			if(expI.compareTo(expJ) > 0) {
				difference.setTerm(terms.get(i));
				i++;
			}
			else if(expI.equals(expJ)) {
				BigInteger differenceValue = terms.get(i).getValue().subtract(other.getTerms().get(j).getValue()).mod(n);
				if(!differenceValue.equals(BigInteger.ZERO)) {
					difference.setTerm(new Term(expI, differenceValue));
				}
				i++;
				j++;
			}
			else {
				difference.setTerm(new Term(other.getTerms().get(j).getExponent(), other.getTerms().get(j).getValue().negate()));
				j++;
			}
		}
		while(i < terms.size()) {
			difference.setTerm(terms.get(i));
			i++;
		}
		while(j < other.getTerms().size()) {
			difference.setTerm(new Term(other.getTerms().get(j).getExponent(), other.getTerms().get(j).getValue().negate()));
			j++;
		}
		return difference;
	}
	
	
	public static PolynomModN pow(PolynomModN x, BigInteger k) {
		PolynomModN poly = x;
		String s = k.toString(2);
		s = s.substring(1, s.length());
		for(int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if(c == '0') {
				poly = poly.multiply(poly);
			}
			if(c == '1') {
				poly = poly.multiply(poly);
				poly = poly.multiply(x);
			}
		}
		return poly;
	}
	
	public PolynomModN[] divideAndRemainder(PolynomModN other) {
		PolynomModN q = new PolynomModN(n);
		PolynomModN r = this;
		PolynomModN b = other;
		//PolynomModuloN r = this.deepCopy();
		//PolynomModuloN b = other.deepCopy();
		    	
		BigInteger d = b.getOrder();
		BigInteger c = b.getTerms().get(0).getValue();
		while(r.getOrder().compareTo(d) >= 0) {
			PolynomModN s = new PolynomModN(n);
		    BigInteger newExp = r.getOrder().subtract(d);
		    BigInteger newValue = (r.getTerms().get(0).getValue()).multiply(c.modInverse(n));
		    s.setTerm(new Term(newExp, newValue));
		    q = q.add(s);
		    r = r.subtract(s.multiply(b));
		}
		PolynomModN[] polynoms = {q, r};
		return polynoms;
	}	
	
	
	public PolynomModN gcd(PolynomModN other, BigInteger n) {
		PolynomModN u = this;
		PolynomModN v = other;
		if((other.getOrder().compareTo(this.getOrder()) > 0)) {
			PolynomModN help = u;
			u = v;
			v = help;
		}
		while(!v.getTerms().isEmpty()) {
			PolynomModN help = u;
			u = v;
			//System.out.println("u = "+u);
			v = help.fastMod(v);
		}
		System.out.println("u = "+u);
		BigInteger c = u.getTerms().get(0).getValue();
		BigInteger cInverse = c.modInverse(n);
		for(Term term : u.getTerms()) {
			u.setTerm(new Term(term.getExponent(), term.getValue().multiply(cInverse)));
		}
		return u;
	}
	
	
	private PolynomModN multiply(PolynomModN other) {
		if(!this.n.equals(other.n)) {
			return null;
		}
		BigInteger thisOrder = this.getOrder().add(BigInteger.ONE);
		BigInteger otherOrder = other.getOrder().add(BigInteger.ONE);
		BigInteger maxOrder = thisOrder.max(otherOrder);
		BigInteger thismaxCoef = this.getMaxCoef();
		BigInteger othermaxCoef = other.getMaxCoef();
		BigInteger maxCondition = maxOrder.multiply(thismaxCoef).multiply(othermaxCoef);
		BigInteger b = BigInteger.ONE;
		while(this.pow(BigInteger.valueOf(2), b).compareTo(maxCondition) <= 0) {
			b = b.add(BigInteger.ONE);
		}
		System.out.println("b = "+b);
		BigInteger x = new BigInteger("0");
		BigInteger y = new BigInteger("0");
		ArrayList<Term> thisTerms = this.getTerms();
		ArrayList<Term> otherTerms = other.getTerms();
		
		for(Term term : thisTerms) {
			BigInteger summand = term.getValue().multiply((BigInteger.valueOf(2)).pow(b.multiply(term.getExponent()).intValue()));
			System.out.println("Wert = "+term.getValue());
			System.out.println("Exponent = "+term.getExponent());
			System.out.println("Summand = "+summand);
			x = x.add(summand);
		}
		
		for(Term term : otherTerms) {
			BigInteger summand = term.getValue().multiply((BigInteger.valueOf(2)).modPow(b.multiply(term.getExponent()), n));
			y = y.add(summand);
		}
		System.out.println("p = "+this.toString());
		System.out.println("p_sum = "+x);
		System.out.println("q = "+other.toString());
		System.out.println("q_sum = "+y);
		//System.out.println(y);
		
		BigInteger u = x.multiply(y);
		String s = u.toString(2);
		System.out.println("Bin�rstring = "+s);
		//System.out.println("u = " +u);
		//System.out.println("s = "+s);
		
		PolynomModN poly = new PolynomModN(this.n);
		
		for(int i = 0; BigInteger.valueOf(i).multiply(b).compareTo(BigInteger.valueOf(s.length())) < 0; i++) {
			BigInteger upper = BigInteger.valueOf(s.length()).subtract(BigInteger.valueOf(i).multiply(b));
			BigInteger lower = (upper.subtract(b)).max(BigInteger.ZERO);
			String bin = s.substring(lower.intValue(), upper.intValue());
			System.out.println("Substring = "+bin);
			//System.out.println("Binary-String = "+bin);
			BigInteger z = new BigInteger(bin, 2);
			//System.out.println("Coefficient = "+z);
			Term term = new Term(BigInteger.valueOf(i), z);
			poly.setTerm(term);
		}
		System.out.println("product = "+poly);
		System.out.println("-------------------------------------");
		return poly;
		
	}
	
	public BigInteger pow(BigInteger x, BigInteger y) {
		String bits = y.toString(2);

		BigInteger z = x;
		BigInteger a = BigInteger.ONE;
		int j = 0;
		for (j = bits.length() - 1; j > 0; j--) {
			if (bits.charAt(j) == '1') {
				a = a.multiply(z);
			}
			z = z.pow(2);
		}
		return a.multiply(z);
	}

	
	private BigInteger getMaxCoef() {
		BigInteger max = BigInteger.valueOf(-1);
		for(int i=0 ; i < terms.size(); i++){
			if(terms.get(i).getValue().compareTo(max) > 0){
				max = terms.get(i).getValue();
			}
		}
		return max;
	}
	
	private PolynomModN fastInversion(BigInteger N, BigInteger n) {
		PolynomModN toInvert = new PolynomModN(n);
		BigInteger constantCoef = terms.get(0).getValue();
		BigInteger constantCoefInverse = constantCoef.modInverse(n);
		for(Term term : terms) {
			toInvert.setTerm(new Term(term.getExponent(),term.getValue().multiply(constantCoefInverse)));
		}
		PolynomModN g = new PolynomModN(n);
		g.setTerm(new Term(BigInteger.ZERO, BigInteger.ONE));
		BigInteger m = BigInteger.ONE;
		
		BigInteger NPlusOne = N.add(BigInteger.ONE);
		while(m.compareTo(NPlusOne) < 0) {
			m = m.multiply(BigInteger.valueOf(2));
			if(m.compareTo(NPlusOne) > 0) {
				m = NPlusOne;
			}
			PolynomModN h = new PolynomModN(n);
			for(Term term : toInvert.getTerms()) {
				if(term.getExponent().compareTo(m) < 0) {
					h.setTerm(term);
				}
			}
			PolynomModN hg = h.multiply(g);
			h = new PolynomModN(n);
			for(Term term : hg.getTerms()) {
				if(term.getExponent().compareTo(m) < 0) {
					h.setTerm(term);
				}
			}
			PolynomModN constructG = new PolynomModN(n);
			PolynomModN two = new PolynomModN(n);
			two.setTerm(new Term(BigInteger.ZERO, BigInteger.valueOf(2)));
			constructG = g.multiply(two.subtract(h));
			g = new PolynomModN(n);
			for(Term term : constructG.getTerms()) {
				if(term.getExponent().compareTo(m) < 0) {
					g.setTerm(term);
				}
			}
		}
		return g;
	}
	
	private PolynomModN reversePolynom(BigInteger degree) {
		if(degree.compareTo(this.getOrder()) > 0) {
			return new PolynomModN(n);
		}
		PolynomModN toReverse = new PolynomModN(n);
		for(int i = terms.size()-1; i >= 0; i--) {
			if(terms.get(i).getExponent().compareTo(degree) <= 0) {
				toReverse.setTerm(terms.get(i));
			}
		}
		PolynomModN reversedPolynom = new PolynomModN(n);
		int size = toReverse.getTerms().size();
		for(int i = 0; i < size; i++) {
		
			reversedPolynom.setTerm(new Term(toReverse.getTerms().get(i).getExponent(), toReverse.getTerms().get(size-1-i).getValue()));
		}
		return reversedPolynom;
	}
	
	private BigInteger ind(BigInteger value) {
		BigInteger index = BigInteger.ZERO;
		int actual = terms.size()-1;
		for(int i = actual; i >= 0; i--) {
			if(terms.get(i).getExponent().compareTo(value) < 0) {
				continue;
			}
			index = terms.get(i).getExponent();
			break;
		}
		return index;
	}
	
	public PolynomModN fastMod(PolynomModN other) {
		PolynomModN nominator = new PolynomModN(n);
		BigInteger leadCoef = terms.get(0).getValue();
		BigInteger leadCoefInverse = leadCoef.modInverse(n);
		for(Term term : terms) {
			nominator.setTerm(new Term(term.getExponent(),term.getValue().multiply(leadCoefInverse)));
		}
		
		if(other.getOrder().equals(BigInteger.ZERO)) {
			//Ggf. noch anpassen, dass Nullpolynome zul�ssig sind!
			return new PolynomModN(n);
		}
		BigInteger d = nominator.getOrder().subtract(other.getOrder());
		if(d.compareTo(BigInteger.ZERO) < 0) {
			return nominator;
		}
		
		PolynomModN x = nominator.reversePolynom(nominator.getOrder());
		PolynomModN y = other.reversePolynom(other.getOrder());
		
		PolynomModN q = y.fastInversion(d, n);
		
		q = q.multiply(x);
		PolynomModN newQ = new PolynomModN(n);
		for(Term term : q.getTerms()) {
			if(term.getExponent().compareTo(d.add(BigInteger.ONE)) < 0) {
				newQ.setTerm(term);
			}
		}
		q = newQ;
		PolynomModN r = x.subtract(q.multiply(y));
		BigInteger i = r.ind(d.add(BigInteger.ONE));
		PolynomModN help = new PolynomModN(n);
		help.setTerm(new Term(i, BigInteger.ONE));
		PolynomModN newr = new PolynomModN(n);
		for(Term term : r.getTerms()) {
			newr.setTerm(new Term(term.getExponent().subtract(i), term.getValue()));
		}

		return newr.reversePolynom(x.getOrder().subtract(i));
		
	} */
}

		



package ecpp;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.MathContext;
import java.util.LinkedList;

import ch.obermuhlner.math.big.BigDecimalMath;

/**
 * Diese Klasse realisiert ein Primalit�tszertifikat f�r den ECPP-Algorithmus
 * @author Sascha Zielke
 *
 */
public class PrimalityCertificate {
	
	//Eine Liste von Zertfikat-Eintr�gen
	LinkedList<CertificateEntry> certificate;
	
	/**
	 * Standard-Konstruktor, erzeugt leeres Zertifikat
	 */
	public PrimalityCertificate() {
		certificate = new LinkedList<CertificateEntry>();
	}
	
	/**
	 * Gibt eine String-Repr�sentation des Zertifikats zur�ck.
	 */
	public String toString() {
		StringBuilder certString = new StringBuilder();
		for(int i = 0; i < certificate.size(); i++) {
			certString.append(certificate.get(i).toString()).append("\n");
		}
		return certString.toString();
	}
	
	/**
	 * Pr�ft ein Primalit�tszertifikat nach Algorithmus 2.33
	 * @return
	 */
	public boolean checkCertificate() {
		//Pr�fe f�r jeden Zertifikat-Eintrag:
		for(int i = 0; i < certificate.size(); i++) {
			//Schritt 1:
			CertificateEntry entry = certificate.get(i);
			if(!entry.getN().gcd(BigInteger.valueOf(6)).equals(BigInteger.ONE)) {
				return false;
			}
			if(!(entry.getN().gcd(BigInteger.valueOf(4).multiply(entry.getA().pow(3)).add(BigInteger.valueOf(27).multiply(entry.getB().pow(2))))).equals(BigInteger.ONE)) {
				return false;
			}
			EllipticCurveModuloN curve = new EllipticCurveModuloN(entry.getA(), entry.getB(), entry.getN());
			//Schritt 2:
			ProjectivePoint U = entry.getU();
			if(!((U.getY().pow(2).mod(entry.getN())).equals((U.getX().pow(3)).add(U.getX().multiply(curve.getA())).add(curve.getB()).mod(entry.getN())))) {
				return false;
			}
			if(U.getZ().equals(BigInteger.ZERO)) {
				return false;
			}
			try {
				ProjectivePoint toTest = (curve.multiply(entry.getS(), U));
				if(!(toTest.getZ()).equals(BigInteger.ZERO)) {
					return false;
				}
			} catch (InversionFailedException e) {
				return false;
			}
			//Schritt 3:
			MathContext mc = new MathContext(10);
			if(new BigDecimal(entry.getS()).compareTo((BigDecimalMath.sqrt(BigDecimalMath.sqrt(new BigDecimal(entry.getN()), mc), mc).add(BigDecimal.ONE)).pow(2)) <= 0)  {
				return false;
			}
		}
		return true;
	}

}
